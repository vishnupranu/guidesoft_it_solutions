import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import FloatingActions from "@/components/ui/floating-actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Sprout, Scale, Users, MapPin, Clock, DollarSign } from "lucide-react";

export default function Careers() {
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["/api/jobs"],
  });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-primary/10 to-purple-600/10 py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Join Our Team
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Help us shape the future of technology education. We're always looking for passionate educators and innovators.
            </p>
          </div>
        </div>

        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Company Culture */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold">Why Work With Us?</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-start space-x-3">
                      <Heart className="w-5 h-5 text-red-500 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Passionate Mission</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          Make a real impact on students' careers and lives
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Sprout className="w-5 h-5 text-green-500 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Growth-Focused</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          Continuous learning and professional development
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Scale className="w-5 h-5 text-blue-500 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Work-Life Balance</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          Flexible schedules and remote work options
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <Users className="w-5 h-5 text-purple-500 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-white">Amazing Team</h4>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          Collaborate with industry experts and innovators
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Job Listings */}
              <div className="lg:col-span-2">
                {isLoading ? (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
                    <p className="mt-4 text-gray-600 dark:text-gray-300">Loading job openings...</p>
                  </div>
                ) : jobs.length === 0 ? (
                  <div className="text-center py-12">
                    <p className="text-xl text-gray-600 dark:text-gray-300">
                      No job openings available at the moment.
                    </p>
                    <p className="text-gray-500 dark:text-gray-400 mt-2">
                      Check back soon for new opportunities!
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {jobs.map((job: any) => (
                      <Card key={job.id} className="hover:shadow-xl transition-all duration-300">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                                {job.title}
                              </h3>
                              <p className="text-gray-600 dark:text-gray-300 mb-3">
                                {job.description}
                              </p>
                              {job.requirements && (
                                <div className="flex flex-wrap gap-2 mb-4">
                                  {job.requirements.slice(0, 3).map((req: string, index: number) => (
                                    <Badge key={index} variant="outline">
                                      {req}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            <div className="text-right ml-6">
                              {job.salary && (
                                <div className="text-lg font-semibold text-primary mb-1">
                                  {job.salary}
                                </div>
                              )}
                              {job.employmentType && (
                                <div className="text-sm text-gray-500 dark:text-gray-400">
                                  {job.employmentType}
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                              {job.location && (
                                <div className="flex items-center space-x-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>{job.location}</span>
                                </div>
                              )}
                              <div className="flex items-center space-x-1">
                                <Clock className="w-4 h-4" />
                                <span>Posted {new Date(job.createdAt).toLocaleDateString()}</span>
                              </div>
                            </div>
                            <Button>Apply Now</Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* View All Jobs Button */}
            {jobs.length > 0 && (
              <div className="text-center mt-12">
                <Button size="lg">View All Openings</Button>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
