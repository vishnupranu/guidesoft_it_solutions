import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { BookOpen, Clock, Award, TrendingUp, Play, CheckCircle } from "lucide-react";
import type { Enrollment } from "@shared/schema";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    document.title = "Student Dashboard | Guidesoft IT Solutions";
  }, []);

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: enrollments, isLoading: enrollmentsLoading } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
    enabled: isAuthenticated,
    retry: false,
    meta: {
      onError: (error: Error) => {
        if (isUnauthorizedError(error)) {
          toast({
            title: "Unauthorized",
            description: "You are logged out. Logging in again...",
            variant: "destructive",
          });
          setTimeout(() => {
            window.location.href = "/api/login";
          }, 500);
          return;
        }
      },
    },
  });

  if (authLoading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <div className="loading-spinner" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const completedCourses = enrollments?.filter(e => e.progress === 100) || [];
  const inProgressCourses = enrollments?.filter(e => e.progress! > 0 && e.progress! < 100) || [];
  const averageProgress = enrollments?.length 
    ? Math.round(enrollments.reduce((sum, e) => sum + (e.progress || 0), 0) / enrollments.length)
    : 0;

  const stats = [
    {
      icon: BookOpen,
      title: "Enrolled Courses",
      value: enrollments?.length || 0,
      gradient: "from-blue-500 to-indigo-600",
    },
    {
      icon: CheckCircle,
      title: "Completed",
      value: completedCourses.length,
      gradient: "from-green-500 to-emerald-600",
    },
    {
      icon: Clock,
      title: "In Progress",
      value: inProgressCourses.length,
      gradient: "from-orange-500 to-yellow-600",
    },
    {
      icon: TrendingUp,
      title: "Average Progress",
      value: `${averageProgress}%`,
      gradient: "from-purple-500 to-pink-600",
    },
  ];

  return (
    <div className="min-h-screen pt-16">
      <div className="container-max section-padding">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Welcome back, {user?.firstName || user?.email || 'Student'}!
          </h1>
          <p className="text-muted-foreground">
            Continue your learning journey and track your progress.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => (
            <Card key={stat.title} className="hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 bg-gradient-to-r ${stat.gradient} rounded-lg flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Current Courses */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  My Courses
                </CardTitle>
              </CardHeader>
              <CardContent>
                {enrollmentsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <Skeleton className="h-16 w-16 rounded-lg" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-3/4 mb-2" />
                          <Skeleton className="h-3 w-1/2 mb-2" />
                          <Skeleton className="h-2 w-full" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : enrollments && enrollments.length > 0 ? (
                  <div className="space-y-4">
                    {enrollments.map((enrollment) => (
                      <div key={enrollment.id} className="flex items-center space-x-4 p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                        <div className="w-16 h-16 bg-gradient-to-r from-primary to-purple-600 rounded-lg flex items-center justify-center">
                          <BookOpen className="w-8 h-8 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground mb-1">
                            Course #{enrollment.courseId}
                          </h3>
                          <div className="flex items-center space-x-4 mb-2">
                            <Badge variant={enrollment.progress === 100 ? "default" : "secondary"}>
                              {enrollment.progress === 100 ? "Completed" : "In Progress"}
                            </Badge>
                            <span className="text-sm text-muted-foreground">
                              {enrollment.progress}% Complete
                            </span>
                          </div>
                          <Progress value={enrollment.progress || 0} className="h-2" />
                        </div>
                        <Button size="sm" variant="outline">
                          {enrollment.progress === 100 ? "Review" : "Continue"}
                          <Play className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">No courses enrolled</h3>
                    <p className="text-muted-foreground mb-4">
                      Start your learning journey by enrolling in a course.
                    </p>
                    <Button className="btn-primary">Browse Courses</Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {completedCourses.length > 0 ? (
                    completedCourses.slice(0, 3).map((enrollment) => (
                      <div key={enrollment.id} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            Completed Course #{enrollment.courseId}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {enrollment.completedAt 
                              ? new Date(enrollment.completedAt).toLocaleDateString()
                              : 'Recently'
                            }
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">No recent activity</p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {completedCourses.length > 0 && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                        <Award className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">Course Completer</p>
                        <p className="text-xs text-muted-foreground">
                          Completed {completedCourses.length} course{completedCourses.length > 1 ? 's' : ''}
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {enrollments && enrollments.length >= 3 && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                        <BookOpen className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">Dedicated Learner</p>
                        <p className="text-xs text-muted-foreground">
                          Enrolled in {enrollments.length} courses
                        </p>
                      </div>
                    </div>
                  )}

                  {averageProgress >= 75 && (
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                        <TrendingUp className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">High Achiever</p>
                        <p className="text-xs text-muted-foreground">
                          {averageProgress}% average progress
                        </p>
                      </div>
                    </div>
                  )}

                  {(completedCourses.length === 0 && (!enrollments || enrollments.length < 3) && averageProgress < 75) && (
                    <p className="text-sm text-muted-foreground">
                      Complete courses to earn achievements!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full btn-primary" size="sm">
                  Browse Courses
                </Button>
                <Button className="w-full" variant="outline" size="sm">
                  Update Profile
                </Button>
                <Button className="w-full" variant="outline" size="sm">
                  View Certificates
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
