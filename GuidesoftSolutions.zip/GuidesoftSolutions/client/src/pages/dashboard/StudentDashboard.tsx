import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Trophy, Clock, Target, Play, Calendar } from "lucide-react";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function StudentDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  const { data: enrollments = [], isLoading: enrollmentsLoading } = useQuery({
    queryKey: ["/api/user/enrollments"],
    enabled: isAuthenticated,
  });

  const { data: courses = [] } = useQuery({
    queryKey: ["/api/courses"],
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-300">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const completedCourses = enrollments.filter((e: any) => e.progress === 100).length;
  const inProgressCourses = enrollments.filter((e: any) => e.progress > 0 && e.progress < 100).length;
  const totalProgress = enrollments.length > 0 
    ? enrollments.reduce((sum: number, e: any) => sum + e.progress, 0) / enrollments.length 
    : 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="pt-16">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-primary/10 to-purple-600/10 py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                  Welcome back, {user?.firstName || "Student"}!
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300">
                  Continue your learning journey and achieve your goals.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <BookOpen className="w-8 h-8 text-blue-500 mr-3" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {enrollments.length}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Enrolled Courses</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <Trophy className="w-8 h-8 text-yellow-500 mr-3" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {completedCourses}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <Clock className="w-8 h-8 text-green-500 mr-3" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {inProgressCourses}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">In Progress</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <Target className="w-8 h-8 text-purple-500 mr-3" />
                  <div>
                    <p className="text-2xl font-bold text-gray-900 dark:text-white">
                      {Math.round(totalProgress)}%
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Avg Progress</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* My Courses */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="w-5 h-5 mr-2" />
                    My Courses
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {enrollmentsLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                    </div>
                  ) : enrollments.length === 0 ? (
                    <div className="text-center py-8">
                      <p className="text-gray-600 dark:text-gray-300 mb-4">
                        You haven't enrolled in any courses yet.
                      </p>
                      <Button>Browse Courses</Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {enrollments.map((enrollment: any) => {
                        const course = courses.find((c: any) => c.id === enrollment.courseId);
                        return (
                          <div key={enrollment.id} className="border rounded-lg p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex-1">
                                <h3 className="font-semibold text-gray-900 dark:text-white">
                                  {course?.title || "Course Title"}
                                </h3>
                                <p className="text-sm text-gray-600 dark:text-gray-300">
                                  {course?.category || "General"}
                                </p>
                              </div>
                              <Badge variant={enrollment.progress === 100 ? "default" : "secondary"}>
                                {enrollment.progress === 100 ? "Completed" : "In Progress"}
                              </Badge>
                            </div>
                            <div className="mb-3">
                              <div className="flex justify-between text-sm mb-1">
                                <span>Progress</span>
                                <span>{enrollment.progress}%</span>
                              </div>
                              <Progress value={enrollment.progress} className="h-2" />
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                <Calendar className="w-4 h-4 mr-1" />
                                Enrolled {new Date(enrollment.enrolledAt).toLocaleDateString()}
                              </div>
                              <Button size="sm" variant="outline">
                                <Play className="w-4 h-4 mr-1" />
                                Continue
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions & Recommendations */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full" variant="outline">
                    Browse New Courses
                  </Button>
                  <Button className="w-full" variant="outline">
                    View Certificates
                  </Button>
                  <Button className="w-full" variant="outline">
                    Join Study Groups
                  </Button>
                  <Button className="w-full" variant="outline">
                    Contact Support
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recommended Courses</CardTitle>
                </CardHeader>
                <CardContent>
                  {courses.slice(0, 3).map((course: any) => (
                    <div key={course.id} className="mb-4 p-3 border rounded-lg">
                      <h4 className="font-medium text-gray-900 dark:text-white text-sm">
                        {course.title}
                      </h4>
                      <p className="text-xs text-gray-600 dark:text-gray-300 mb-2">
                        {course.category}
                      </p>
                      <Button size="sm" className="w-full">
                        Enroll Now
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
