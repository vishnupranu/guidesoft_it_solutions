import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import FloatingActions from "@/components/ui/floating-actions";
import BlogSection from "@/components/sections/BlogSection";

export default function Blog() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="pt-16">
        <div className="bg-gradient-to-r from-orange-600/10 to-red-600/10 py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Latest Insights & News
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Stay updated with the latest trends, tips, and insights from the world of technology.
            </p>
          </div>
        </div>
        <BlogSection />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
