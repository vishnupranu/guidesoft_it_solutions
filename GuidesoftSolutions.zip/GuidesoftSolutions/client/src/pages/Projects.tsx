import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import FloatingActions from "@/components/ui/floating-actions";
import ProjectsSection from "@/components/sections/ProjectsSection";

export default function Projects() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main className="pt-16">
        <div className="bg-gradient-to-r from-purple-600/10 to-pink-600/10 py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
              Student Success Projects
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Explore the amazing projects our students have built during their learning journey.
            </p>
          </div>
        </div>
        <ProjectsSection />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
