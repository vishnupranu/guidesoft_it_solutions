import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Clock, DollarSign, Heart, Zap, Scale, Users } from "lucide-react";

export default function CareersSection() {
  const whyWorkWithUs = [
    {
      icon: Heart,
      title: "Passionate Mission",
      description: "Make a real impact on students' careers and lives",
      color: "text-red-500",
    },
    {
      icon: Zap,
      title: "Growth-Focused",
      description: "Continuous learning and professional development",
      color: "text-green-500",
    },
    {
      icon: Scale,
      title: "Work-Life Balance",
      description: "Flexible schedules and remote work options",
      color: "text-blue-500",
    },
    {
      icon: Users,
      title: "Amazing Team",
      description: "Collaborate with industry experts and innovators",
      color: "text-purple-500",
    },
  ];

  const jobs = [
    {
      id: 1,
      title: "Senior Software Developer Instructor",
      description: "Lead our full-stack development curriculum and mentor students in modern web technologies.",
      category: "Teaching",
      location: "San Francisco, CA",
      type: "Remote / Full-time",
      salaryMin: 85000,
      salaryMax: 120000,
      technologies: ["React", "Node.js", "Teaching"],
      postedDays: 2,
    },
    {
      id: 2,
      title: "Cloud Solutions Architect",
      description: "Design and deliver cloud infrastructure training programs for enterprise clients.",
      category: "Teaching",
      location: "Seattle, WA",
      type: "Hybrid / Full-time",
      salaryMin: 90000,
      salaryMax: 130000,
      technologies: ["AWS", "Azure", "Kubernetes"],
      postedDays: 5,
    },
    {
      id: 3,
      title: "Cybersecurity Training Specialist",
      description: "Develop and deliver comprehensive cybersecurity training programs and certifications.",
      category: "Teaching",
      location: "Austin, TX",
      type: "Remote / Full-time",
      salaryMin: 80000,
      salaryMax: 110000,
      technologies: ["CISSP", "Ethical Hacking", "Security"],
      postedDays: 7,
    },
    {
      id: 4,
      title: "Data Science Curriculum Developer",
      description: "Create engaging data science and machine learning courses for students of all levels.",
      category: "Content",
      location: "New York, NY",
      type: "Hybrid / Full-time",
      salaryMin: 75000,
      salaryMax: 105000,
      technologies: ["Python", "TensorFlow", "Data Analysis"],
      postedDays: 3,
    },
  ];

  const formatSalary = (min: number, max: number) => {
    return `$${(min / 1000).toFixed(0)}K - $${(max / 1000).toFixed(0)}K`;
  };

  const getTechColor = (tech: string) => {
    const colors = {
      "React": "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-200",
      "Node.js": "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-200",
      "Teaching": "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-200",
      "AWS": "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-200",
      "Azure": "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-200",
      "Kubernetes": "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-200",
      "CISSP": "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-200",
      "Ethical Hacking": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-200",
      "Security": "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-200",
      "Python": "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/20 dark:text-indigo-200",
      "TensorFlow": "bg-pink-100 text-pink-800 dark:bg-pink-900/20 dark:text-pink-200",
      "Data Analysis": "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/20 dark:text-cyan-200",
    };
    return colors[tech as keyof typeof colors] || "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-200";
  };

  return (
    <section className="section-padding bg-muted/50">
      <div className="container-max">
        <div className="text-center mb-16">
          <Badge className="section-badge bg-purple-100 text-purple-600 hover:bg-purple-200 dark:bg-purple-900/20 dark:text-purple-400">
            Join Our Team
          </Badge>
          <h2 className="section-title">
            Shape the Future of{" "}
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Technology Education
            </span>
          </h2>
          <p className="section-subtitle">
            Help us shape the future of technology education. We're always looking for passionate educators and innovators.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Company Culture */}
          <div className="lg:col-span-1">
            <Card className="p-8 h-full">
              <h3 className="text-2xl font-bold text-foreground mb-6">Why Work With Us?</h3>
              <div className="space-y-4">
                {whyWorkWithUs.map((item) => (
                  <div key={item.title} className="flex items-start space-x-3">
                    <item.icon className={`${item.color} mt-1 w-5 h-5`} />
                    <div>
                      <h4 className="font-semibold text-foreground">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Job Listings */}
          <div className="lg:col-span-2">
            <div className="space-y-6">
              {jobs.map((job) => (
                <Card key={job.id} className="job-card">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-foreground mb-2">{job.title}</h3>
                        <p className="text-muted-foreground mb-3">{job.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {job.technologies.map((tech) => (
                            <Badge key={tech} className={getTechColor(tech)}>
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="text-right ml-6">
                        <div className="text-lg font-semibold text-primary mb-1">
                          {formatSalary(job.salaryMin, job.salaryMax)}
                        </div>
                        <div className="text-sm text-muted-foreground">{job.type}</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {job.location}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          Posted {job.postedDays} days ago
                        </div>
                      </div>
                      <Button className="btn-primary">Apply Now</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* View All Jobs Button */}
        <div className="text-center mt-12">
          <Button className="btn-primary" size="lg">
            View All Openings
          </Button>
        </div>
      </div>
    </section>
  );
}
