import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";

const slides = [
  {
    id: 1,
    title: "Master Technology Skills",
    subtitle: "Build Your Future",
    description: "Accelerate your career with expert-led courses in software development, cloud computing, AI, and cybersecurity.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Students learning technology in modern classroom",
    primaryAction: { text: "Start Learning Today", href: "/services" },
    secondaryAction: { text: "View Courses", href: "/services" },
    gradient: "from-primary/10 via-secondary/5 to-indigo-100/20 dark:from-primary/20 dark:via-secondary/10 dark:to-indigo-900/30"
  },
  {
    id: 2,
    title: "10,000+ Success Stories",
    subtitle: "Join Thousands",
    description: "Join thousands of professionals who've transformed their careers with our comprehensive training programs.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Professional instructor teaching technology skills",
    primaryAction: { text: "View Success Stories", href: "/about" },
    secondaryAction: { text: "Get Started", href: "/contact" },
    gradient: "from-emerald-50 to-teal-100 dark:from-emerald-900/20 dark:to-teal-900/30"
  },
  {
    id: 3,
    title: "Learn from Industry Experts",
    subtitle: "Expert Instructors",
    description: "Our instructors are seasoned professionals from top tech companies with real-world experience.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Professional instructor teaching technology skills",
    primaryAction: { text: "Meet Our Instructors", href: "/about" },
    secondaryAction: { text: "Explore Courses", href: "/services" },
    gradient: "from-purple-50 to-indigo-100 dark:from-purple-900/20 dark:to-indigo-900/30"
  },
  {
    id: 4,
    title: "Hands-on Practice",
    subtitle: "Real Projects",
    description: "Build real projects, work with live environments, and get the practical experience employers demand.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600",
    alt: "Students working on hands-on technology projects",
    primaryAction: { text: "View Projects", href: "/projects" },
    secondaryAction: { text: "Start Building", href: "/services" },
    gradient: "from-orange-50 to-red-100 dark:from-orange-900/20 dark:to-red-900/30"
  }
];

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <section className="relative h-screen overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 bg-gradient-to-br ${slide.gradient} flex items-center transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="text-center lg:text-left">
                <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
                  {slide.title.includes("Technology") ? (
                    <>
                      Master <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Technology</span> Skills
                    </>
                  ) : slide.title.includes("Success") ? (
                    <>
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600">10,000+</span> Success Stories
                    </>
                  ) : slide.title.includes("Industry") ? (
                    <>
                      Learn from <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">Industry Experts</span>
                    </>
                  ) : (
                    <>
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600">Hands-on</span> Practice
                    </>
                  )}
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl">
                  {slide.description}
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <Button size="lg" asChild>
                    <Link href={slide.primaryAction.href}>
                      {slide.primaryAction.text}
                    </Link>
                  </Button>
                  <Button variant="outline" size="lg" asChild>
                    <Link href={slide.secondaryAction.href}>
                      {slide.secondaryAction.text}
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="relative">
                <img
                  src={slide.image}
                  alt={slide.alt}
                  className="rounded-2xl shadow-2xl w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Controls */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm p-3 rounded-full shadow-lg hover:shadow-xl transition-all z-10"
      >
        <ChevronLeft className="w-6 h-6 text-gray-600 dark:text-gray-300" />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm p-3 rounded-full shadow-lg hover:shadow-xl transition-all z-10"
      >
        <ChevronRight className="w-6 h-6 text-gray-600 dark:text-gray-300" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2 z-10">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? "bg-primary" : "bg-gray-300 hover:bg-gray-400"
            }`}
          />
        ))}
      </div>
    </section>
  );
}
