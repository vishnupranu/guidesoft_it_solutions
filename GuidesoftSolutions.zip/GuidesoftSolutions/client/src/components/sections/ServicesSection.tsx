import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Code, Cloud, Shield, Brain, Smartphone, Infinity } from "lucide-react";

const services = [
  {
    id: 1,
    title: "Software Development",
    description: "Master full-stack development with modern frameworks and best practices.",
    icon: Code,
    gradient: "from-blue-50 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/30",
    iconGradient: "from-blue-500 to-indigo-600",
    features: ["React.js & Next.js", "Node.js & Express", "Database Design", "API Development"],
  },
  {
    id: 2,
    title: "Cloud Computing",
    description: "Build scalable solutions with AWS, Azure, and Google Cloud platforms.",
    icon: Cloud,
    gradient: "from-emerald-50 to-teal-100 dark:from-emerald-900/20 dark:to-teal-900/30",
    iconGradient: "from-emerald-500 to-teal-600",
    features: ["AWS Solutions Architect", "Azure DevOps", "Kubernetes & Docker", "Serverless Architecture"],
  },
  {
    id: 3,
    title: "Cybersecurity",
    description: "Protect digital assets with comprehensive security training and certifications.",
    icon: Shield,
    gradient: "from-red-50 to-pink-100 dark:from-red-900/20 dark:to-pink-900/30",
    iconGradient: "from-red-500 to-pink-600",
    features: ["Ethical Hacking", "Security Analysis", "CISSP Preparation", "Incident Response"],
  },
  {
    id: 4,
    title: "Data Science & AI",
    description: "Unlock insights from data with machine learning and artificial intelligence.",
    icon: Brain,
    gradient: "from-purple-50 to-violet-100 dark:from-purple-900/20 dark:to-violet-900/30",
    iconGradient: "from-purple-500 to-violet-600",
    features: ["Python & R Programming", "Machine Learning", "Deep Learning", "Data Visualization"],
  },
  {
    id: 5,
    title: "Mobile Development",
    description: "Create stunning mobile apps for iOS and Android platforms.",
    icon: Smartphone,
    gradient: "from-orange-50 to-yellow-100 dark:from-orange-900/20 dark:to-yellow-900/30",
    iconGradient: "from-orange-500 to-yellow-600",
    features: ["Flutter Development", "React Native", "iOS Development", "Android Development"],
  },
  {
    id: 6,
    title: "DevOps",
    description: "Streamline development and deployment with modern DevOps practices.",
    icon: Infinity,
    gradient: "from-cyan-50 to-blue-100 dark:from-cyan-900/20 dark:to-blue-900/30",
    iconGradient: "from-cyan-500 to-blue-600",
    features: ["CI/CD Pipelines", "Infrastructure as Code", "Monitoring & Logging", "Automation Tools"],
  },
];

export default function ServicesSection() {
  return (
    <section className="py-20 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Our Training Programs
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Comprehensive courses designed to take you from beginner to industry-ready professional.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const IconComponent = service.icon;
            return (
              <Card 
                key={service.id} 
                className={`bg-gradient-to-br ${service.gradient} hover:shadow-xl transition-all duration-300 hover:-translate-y-1`}
              >
                <CardHeader>
                  <div className={`w-16 h-16 bg-gradient-to-r ${service.iconGradient} rounded-xl flex items-center justify-center mb-6`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-300 mb-6">
                    {service.description}
                  </p>
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <CheckCircle className="w-4 h-4 text-primary" />
                        <span className="text-sm text-gray-600 dark:text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full bg-gradient-to-r ${service.iconGradient} hover:shadow-lg transition-all duration-200`}
                  >
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
