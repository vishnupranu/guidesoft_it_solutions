import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle, ChevronUp } from "lucide-react";

export default function FloatingActions() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.pageYOffset > 300);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const openWhatsApp = () => {
    window.open("https://wa.me/1234567890", "_blank");
  };

  return (
    <div className="floating-action">
      {/* WhatsApp Chat */}
      <Button
        onClick={openWhatsApp}
        className="whatsapp-btn group"
        size="lg"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="ml-2 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
          Chat with us
        </span>
      </Button>

      {/* Scroll to Top */}
      {showScrollTop && (
        <Button
          onClick={scrollToTop}
          className="scroll-to-top"
          size="icon"
        >
          <ChevronUp className="w-5 h-5" />
        </Button>
      )}
    </div>
  );
}
