import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MessageCircle, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";

export default function FloatingActions() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.pageYOffset > 300);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <div className="fixed bottom-6 right-6 flex flex-col space-y-3 z-50">
      {/* WhatsApp Chat */}
      <Button
        size="lg"
        className="bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 group"
        asChild
      >
        <a
          href="https://wa.me/1234567890"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="ml-2 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity max-w-0 group-hover:max-w-xs overflow-hidden">
            Chat with us
          </span>
        </a>
      </Button>

      {/* Scroll to Top */}
      <Button
        size="lg"
        onClick={scrollToTop}
        className={cn(
          "rounded-full shadow-lg hover:shadow-xl transition-all duration-300",
          showScrollTop
            ? "opacity-100 translate-y-0"
            : "opacity-0 translate-y-2 pointer-events-none"
        )}
      >
        <ChevronUp className="w-6 h-6" />
        <span className="sr-only">Scroll to top</span>
      </Button>
    </div>
  );
}
