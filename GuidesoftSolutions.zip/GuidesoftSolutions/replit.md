# replit.md

## Overview

This is a full-stack web application for Guidesoft IT Solutions - an educational technology platform offering professional training courses. The application features a modern React frontend with TypeScript, an Express.js backend, and uses Drizzle ORM with PostgreSQL for data management. The platform includes user authentication via Replit Auth, course management, project showcases, blog functionality, and contact forms.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **Build Tool**: Vite for development and bundling
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript (ES modules)
- **API Pattern**: RESTful API with JSON responses
- **Authentication**: Replit OpenID Connect (OIDC) authentication
- **Session Management**: Express sessions with PostgreSQL store

### Database Architecture
- **Database**: PostgreSQL (via Neon serverless)
- **ORM**: Drizzle ORM with schema-first approach
- **Migrations**: Drizzle Kit for database schema management
- **Connection**: Connection pooling via @neondatabase/serverless

## Key Components

### Authentication System
- **Provider**: Replit OIDC authentication
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **User Roles**: Three-tier system (student, trainer, admin)
- **Authorization**: Route-based protection with role-specific dashboards

### Data Models
- **Users**: Profile management with role-based access
- **Courses**: Training program catalog with categories and difficulty levels
- **Projects**: Student project showcases with technology tags
- **Blog Posts**: Content management with publishing status
- **Job Postings**: Career opportunities listing
- **Enrollments**: Student course registration tracking
- **Contact Submissions**: Customer inquiry management

### UI Components
- **Design System**: shadcn/ui components with Radix UI primitives
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Theme System**: Light/dark mode toggle with CSS variables
- **Accessibility**: ARIA-compliant components and keyboard navigation

## Data Flow

### Authentication Flow
1. User accesses protected route
2. Replit Auth redirects to OIDC provider
3. Successful authentication creates/updates user record
4. Session established with PostgreSQL store
5. Role-based dashboard redirection

### API Request Flow
1. Frontend makes authenticated requests with credentials
2. Express middleware logs requests and handles errors
3. Route handlers interact with Drizzle ORM
4. Database queries executed against PostgreSQL
5. JSON responses returned to frontend
6. TanStack Query manages caching and state updates

### Content Management Flow
1. Admin/trainer creates content via dashboard
2. Form validation using Zod schemas
3. API endpoints handle CRUD operations
4. Database updates trigger cache invalidation
5. Frontend components reactively update

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection and query execution
- **drizzle-orm**: Database ORM and query builder
- **@tanstack/react-query**: Server state management and caching
- **@radix-ui/react-***: Accessible UI component primitives
- **wouter**: Lightweight client-side routing
- **zod**: Schema validation for forms and APIs

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Type safety and developer experience
- **Tailwind CSS**: Utility-first styling framework
- **ESLint/Prettier**: Code quality and formatting

### Replit-Specific Integrations
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Code navigation assistance

## Deployment Strategy

### Development Environment
- **Server**: Express.js with Vite middleware for HMR
- **Database**: Neon PostgreSQL with environment-based connection
- **Asset Serving**: Vite dev server with proxy configuration
- **Error Handling**: Runtime error overlay for debugging

### Production Build
- **Frontend**: Vite builds optimized React bundle
- **Backend**: ESBuild bundles Express server for Node.js
- **Assets**: Static files served from Express with fallback routing
- **Database**: Production PostgreSQL instance via DATABASE_URL

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **SESSION_SECRET**: Session encryption key (required)
- **REPLIT_DOMAINS**: Allowed domains for OIDC (required)
- **NODE_ENV**: Environment flag for conditional features

### File Structure
- **client/**: React frontend application
- **server/**: Express.js backend with API routes
- **shared/**: Common TypeScript interfaces and schemas
- **dist/**: Production build output directory
- **migrations/**: Database migration files