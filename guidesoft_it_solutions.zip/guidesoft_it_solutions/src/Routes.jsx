import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import HomePage from "pages/home-page";
import Login from "pages/login";
import Register from "pages/register";
import StudentDashboard from "pages/student-dashboard";
import TrainerDashboard from "pages/trainer-dashboard";
import AdminControlPanel from "pages/admin-control-panel";
import NotFound from "pages/NotFound";
import ProtectedRoute from './components/ui/ProtectedRoute';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Public Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/home-page" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        
        {/* Dashboard Routes - Direct access for Rocket platform development preview */}
        {/* TODO: Before production deployment
             1. Wrap with <ProtectedRoute> component
             2. Add requiredRole prop where needed
             3. Test all authentication flows
        */}
        <Route path="/student-dashboard" element={<StudentDashboard />} />
        <Route path="/trainer-dashboard" element={<TrainerDashboard />} />
        <Route path="/admin-control-panel" element={<AdminControlPanel />} />
        
        {/* 404 Route */}
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;