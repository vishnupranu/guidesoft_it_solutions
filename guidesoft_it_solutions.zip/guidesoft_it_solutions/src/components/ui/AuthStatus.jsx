import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import Button from './Button';
import Icon from '../AppIcon';

const AuthStatus = ({ className = '' }) => {
  const { user, userProfile, loading, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/');
    } catch (error) {
      console.log('Sign out error:', error);
    }
  };

  if (loading) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <div className="w-4 h-4 border-2 border-muted-foreground border-t-transparent rounded-full animate-spin"></div>
        <span className="text-sm text-muted-foreground">Loading...</span>
      </div>
    );
  }

  if (!user) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate('/login')}
        >
          Sign In
        </Button>
        <Button
          variant="default"
          size="sm"
          onClick={() => navigate('/register')}
        >
          Sign Up
        </Button>
      </div>
    );
  }

  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className="flex items-center space-x-2">
        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
          <Icon name="User" size={16} className="text-primary" />
        </div>
        <div className="text-sm">
          <p className="font-medium text-foreground">
            {userProfile?.full_name || userProfile?.first_name || 'User'}
          </p>
          <p className="text-muted-foreground capitalize">
            {userProfile?.role || 'Member'}
          </p>
        </div>
      </div>
      <Button
        variant="outline"
        size="sm"
        onClick={handleSignOut}
        iconName="LogOut"
        iconPosition="left"
      >
        Sign Out
      </Button>
    </div>
  );
};

export default AuthStatus;