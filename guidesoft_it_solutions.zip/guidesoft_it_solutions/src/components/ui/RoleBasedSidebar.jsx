import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const RoleBasedSidebar = ({ 
  user = { role: 'student' }, 
  isCollapsed = false, 
  onToggleCollapse = () => {} 
}) => {
  const location = useLocation();
  const [expandedSections, setExpandedSections] = useState({});

  const toggleSection = (sectionKey) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionKey]: !prev[sectionKey]
    }));
  };

  const getNavigationItems = () => {
    switch (user.role) {
      case 'student':
        return [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: 'LayoutDashboard',
            href: '/student-dashboard',
            active: location.pathname === '/student-dashboard'
          },
          {
            key: 'courses',
            label: 'My Courses',
            icon: 'BookOpen',
            children: [
              { label: 'Current Courses', href: '#current-courses' },
              { label: 'Completed Courses', href: '#completed-courses' },
              { label: 'Browse Catalog', href: '#browse-catalog' }
            ]
          },
          {
            key: 'progress',
            label: 'Progress',
            icon: 'TrendingUp',
            href: '#progress'
          },
          {
            key: 'assignments',
            label: 'Assignments',
            icon: 'FileText',
            href: '#assignments',
            badge: '3'
          },
          {
            key: 'resources',
            label: 'Resources',
            icon: 'Library',
            children: [
              { label: 'Study Materials', href: '#study-materials' },
              { label: 'Code Examples', href: '#code-examples' },
              { label: 'Video Library', href: '#video-library' }
            ]
          },
          {
            key: 'certificates',
            label: 'Certificates',
            icon: 'Award',
            href: '#certificates'
          }
        ];

      case 'trainer':
        return [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: 'LayoutDashboard',
            href: '/trainer-dashboard',
            active: location.pathname === '/trainer-dashboard'
          },
          {
            key: 'courses',
            label: 'My Courses',
            icon: 'BookOpen',
            children: [
              { label: 'Active Courses', href: '#active-courses' },
              { label: 'Course Builder', href: '#course-builder' },
              { label: 'Draft Courses', href: '#draft-courses' }
            ]
          },
          {
            key: 'students',
            label: 'Students',
            icon: 'Users',
            children: [
              { label: 'All Students', href: '#all-students' },
              { label: 'Student Progress', href: '#student-progress' },
              { label: 'Grading', href: '#grading' }
            ]
          },
          {
            key: 'content',
            label: 'Content Library',
            icon: 'Library',
            children: [
              { label: 'Lessons', href: '#lessons' },
              { label: 'Assignments', href: '#assignments' },
              { label: 'Resources', href: '#resources' }
            ]
          },
          {
            key: 'analytics',
            label: 'Analytics',
            icon: 'BarChart3',
            href: '#analytics'
          },
          {
            key: 'calendar',
            label: 'Schedule',
            icon: 'Calendar',
            href: '#schedule'
          }
        ];

      case 'admin':
        return [
          {
            key: 'dashboard',
            label: 'Dashboard',
            icon: 'LayoutDashboard',
            href: '/admin-control-panel',
            active: location.pathname === '/admin-control-panel'
          },
          {
            key: 'users',
            label: 'User Management',
            icon: 'Users',
            children: [
              { label: 'All Users', href: '#all-users' },
              { label: 'Students', href: '#students' },
              { label: 'Trainers', href: '#trainers' },
              { label: 'Administrators', href: '#administrators' }
            ]
          },
          {
            key: 'courses',
            label: 'Course Management',
            icon: 'BookOpen',
            children: [
              { label: 'All Courses', href: '#all-courses' },
              { label: 'Course Categories', href: '#course-categories' },
              { label: 'Approval Queue', href: '#approval-queue' }
            ]
          },
          {
            key: 'content',
            label: 'Content Oversight',
            icon: 'Library',
            children: [
              { label: 'Content Review', href: '#content-review' },
              { label: 'Resource Library', href: '#resource-library' },
              { label: 'Quality Control', href: '#quality-control' }
            ]
          },
          {
            key: 'analytics',
            label: 'System Analytics',
            icon: 'BarChart3',
            children: [
              { label: 'Platform Usage', href: '#platform-usage' },
              { label: 'Performance Metrics', href: '#performance-metrics' },
              { label: 'Reports', href: '#reports' }
            ]
          },
          {
            key: 'settings',
            label: 'System Settings',
            icon: 'Settings',
            children: [
              { label: 'General Settings', href: '#general-settings' },
              { label: 'Security', href: '#security' },
              { label: 'Integrations', href: '#integrations' }
            ]
          }
        ];

      default:
        return [];
    }
  };

  const navigationItems = getNavigationItems();

  const renderNavItem = (item) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedSections[item.key];
    const isActive = item.active || (item.href && location.pathname === item.href);

    if (hasChildren) {
      return (
        <div key={item.key} className="space-y-1">
          <button
            onClick={() => toggleSection(item.key)}
            className={`w-full flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
              isActive
                ? 'bg-primary text-primary-foreground'
                : 'text-muted-foreground hover:text-foreground hover:bg-muted'
            }`}
          >
            <div className="flex items-center space-x-3">
              <Icon name={item.icon} size={18} />
              {!isCollapsed && <span>{item.label}</span>}
            </div>
            {!isCollapsed && (
              <Icon 
                name="ChevronDown" 
                size={16} 
                className={`transform transition-transform duration-200 ${
                  isExpanded ? 'rotate-180' : ''
                }`}
              />
            )}
          </button>
          
          {!isCollapsed && isExpanded && (
            <div className="ml-6 space-y-1">
              {item.children.map((child, index) => (
                <Link
                  key={index}
                  to={child.href}
                  className="block px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition-colors duration-200"
                >
                  {child.label}
                </Link>
              ))}
            </div>
          )}
        </div>
      );
    }

    return (
      <Link
        key={item.key}
        to={item.href}
        className={`flex items-center justify-between px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
          isActive
            ? 'bg-primary text-primary-foreground'
            : 'text-muted-foreground hover:text-foreground hover:bg-muted'
        }`}
      >
        <div className="flex items-center space-x-3">
          <Icon name={item.icon} size={18} />
          {!isCollapsed && <span>{item.label}</span>}
        </div>
        {!isCollapsed && item.badge && (
          <span className="px-2 py-1 text-xs font-medium bg-accent text-accent-foreground rounded-full">
            {item.badge}
          </span>
        )}
      </Link>
    );
  };

  return (
    <aside 
      className={`fixed left-0 top-16 bottom-0 z-40 bg-card border-r border-border transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      } lg:translate-x-0 transform ${
        isCollapsed ? '' : 'translate-x-0'
      }`}
    >
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          {!isCollapsed && (
            <h2 className="text-lg font-semibold text-foreground capitalize">
              {user.role} Portal
            </h2>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="h-8 w-8"
          >
            <Icon name={isCollapsed ? "ChevronRight" : "ChevronLeft"} size={16} />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navigationItems.map(renderNavItem)}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-border">
          {!isCollapsed && (
            <div className="text-xs text-muted-foreground">
              <p>Guidesoft IT Solutions</p>
              <p>© 2025 All rights reserved</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};

export default RoleBasedSidebar;