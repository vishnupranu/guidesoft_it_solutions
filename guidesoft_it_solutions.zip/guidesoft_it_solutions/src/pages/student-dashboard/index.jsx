import React, { useState, useEffect } from 'react';
import AuthenticatedHeader from '../../components/ui/AuthenticatedHeader';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import WelcomeHeader from './components/WelcomeHeader';
import ProgressOverview from './components/ProgressOverview';
import ContinueLearning from './components/ContinueLearning';
import CourseCatalog from './components/CourseCatalog';
import ActivityFeed from './components/ActivityFeed';
import QuickActions from './components/QuickActions';

const StudentDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Mock student data
  const studentData = {
    id: 1,
    firstName: "Alex",
    lastName: "Johnson",
    email: "alex.johnson@email.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    role: "student",
    learningStreak: 15,
    totalHours: 127,
    certificatesEarned: 3
  };

  // Mock progress data
  const progressData = {
    completedCourses: 8,
    totalCourses: 12,
    overallProgress: 67,
    certificatesEarned: 3,
    upcomingDeadlines: 2
  };

  // Mock recent courses data
  const recentCourses = [
    {
      id: 1,
      title: "Advanced React Development",
      description: "Master advanced React concepts including hooks, context, and performance optimization techniques.",
      thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=250&fit=crop",
      progress: 75,
      duration: "8h 30m",
      timeLeft: "2h 15m"
    },
    {
      id: 2,
      title: "Node.js Backend Development",
      description: "Build scalable backend applications with Node.js, Express, and MongoDB integration.",
      thumbnail: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=250&fit=crop",
      progress: 45,
      duration: "12h 45m",
      timeLeft: "7h 20m"
    },
    {
      id: 3,
      title: "Database Design Fundamentals",
      description: "Learn database design principles, normalization, and SQL query optimization strategies.",
      thumbnail: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400&h=250&fit=crop",
      progress: 90,
      duration: "6h 15m",
      timeLeft: "40m"
    }
  ];

  // Mock available courses data
  const availableCourses = [
    {
      id: 4,
      title: "Python for Data Science",
      description: "Comprehensive introduction to Python programming for data analysis and machine learning applications.",
      thumbnail: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=400&h=250&fit=crop",
      category: "data-science",
      level: "beginner",
      duration: "15h 30m",
      instructor: "Dr. Sarah Chen",
      enrolledStudents: 1247,
      rating: 4.8,
      price: 89
    },
    {
      id: 5,
      title: "Cybersecurity Essentials",
      description: "Learn fundamental cybersecurity concepts, threat analysis, and security best practices for modern applications.",
      thumbnail: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=400&h=250&fit=crop",
      category: "cybersecurity",
      level: "intermediate",
      duration: "20h 15m",
      instructor: "Michael Rodriguez",
      enrolledStudents: 892,
      rating: 4.9,
      price: 129
    },
    {
      id: 6,
      title: "AWS Cloud Fundamentals",
      description: "Master Amazon Web Services basics including EC2, S3, RDS, and deployment strategies for cloud applications.",
      thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=250&fit=crop",
      category: "cloud-computing",
      level: "beginner",
      duration: "18h 45m",
      instructor: "Jennifer Liu",
      enrolledStudents: 2156,
      rating: 4.7,
      price: 0
    },
    {
      id: 7,
      title: "Mobile App Development with React Native",
      description: "Build cross-platform mobile applications using React Native, navigation, and native device integration.",
      thumbnail: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=400&h=250&fit=crop",
      category: "mobile-development",
      level: "intermediate",
      duration: "25h 20m",
      instructor: "David Park",
      enrolledStudents: 1543,
      rating: 4.6,
      price: 149
    },
    {
      id: 8,
      title: "Full Stack Web Development Bootcamp",
      description: "Complete web development course covering HTML, CSS, JavaScript, React, Node.js, and database integration.",
      thumbnail: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&h=250&fit=crop",
      category: "web-development",
      level: "advanced",
      duration: "40h 30m",
      instructor: "Emily Watson",
      enrolledStudents: 3421,
      rating: 4.9,
      price: 199
    },
    {
      id: 9,
      title: "Machine Learning with TensorFlow",
      description: "Deep dive into machine learning algorithms, neural networks, and TensorFlow implementation techniques.",
      thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=250&fit=crop",
      category: "data-science",
      level: "advanced",
      duration: "35h 15m",
      instructor: "Dr. Robert Kim",
      enrolledStudents: 987,
      rating: 4.8,
      price: 179
    }
  ];

  // Mock activity feed data
  const activities = [
    {
      id: 1,
      type: "achievement",
      title: "Course Completed!",
      description: "Congratulations! You\'ve successfully completed \'Database Design Fundamentals\' with a score of 95%.",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      actionUrl: "#certificates"
    },
    {
      id: 2,
      type: "assignment",
      title: "New Assignment Available",
      description: "A new assignment \'React Hooks Implementation\' has been posted for Advanced React Development course.",
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      actionUrl: "#assignments"
    },
    {
      id: 3,
      type: "course_update",
      title: "Course Content Updated",
      description: "New video lectures and practice exercises have been added to Node.js Backend Development course.",
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000), // 6 hours ago
      actionUrl: "#courses"
    },
    {
      id: 4,
      type: "announcement",
      title: "Live Session Scheduled",
      description: "Join our live Q&A session on \'Advanced React Patterns\' scheduled for tomorrow at 3:00 PM EST.",
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000), // 8 hours ago
      actionUrl: "#calendar"
    },
    {
      id: 5,
      type: "certificate",
      title: "Certificate Ready",
      description: "Your certificate for 'JavaScript Fundamentals' is now available for download.",
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      actionUrl: "#certificates"
    }
  ];

  useEffect(() => {
    document.title = "Student Dashboard - Guidesoft IT Solutions";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <AuthenticatedHeader user={studentData} />
      
      <div className="flex">
        <RoleBasedSidebar 
          user={studentData}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />
        
        <main className={`flex-1 transition-all duration-300 ${
          isSidebarCollapsed ? 'ml-16' : 'ml-64'
        } pt-16`}>
          <div className="p-6 max-w-7xl mx-auto">
            <WelcomeHeader student={studentData} />
            
            <ProgressOverview progressData={progressData} />
            
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 space-y-6">
                <ContinueLearning recentCourses={recentCourses} />
                <CourseCatalog availableCourses={availableCourses} />
              </div>
              
              <div className="space-y-6">
                <QuickActions />
                <ActivityFeed activities={activities} />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default StudentDashboard;