import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActions = () => {
  const quickActions = [
    {
      title: 'Assignments',
      description: 'View pending assignments',
      icon: 'FileText',
      color: 'text-primary bg-primary/10',
      badge: '3',
      action: () => console.log('Navigate to assignments')
    },
    {
      title: 'Downloads',
      description: 'Access course materials',
      icon: 'Download',
      color: 'text-success bg-success/10',
      action: () => console.log('Navigate to downloads')
    },
    {
      title: 'Support',
      description: 'Get help from instructors',
      icon: 'HelpCircle',
      color: 'text-warning bg-warning/10',
      action: () => console.log('Navigate to support')
    },
    {
      title: 'Calendar',
      description: 'View upcoming sessions',
      icon: 'Calendar',
      color: 'text-accent bg-accent/10',
      action: () => console.log('Navigate to calendar')
    },
    {
      title: 'Certificates',
      description: 'Download certificates',
      icon: 'Award',
      color: 'text-error bg-error/10',
      action: () => console.log('Navigate to certificates')
    },
    {
      title: 'Profile',
      description: 'Update your profile',
      icon: 'User',
      color: 'text-secondary bg-secondary/10',
      action: () => console.log('Navigate to profile')
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <h2 className="text-xl font-semibold text-foreground mb-6">Quick Actions</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {quickActions.map((action, index) => (
          <button
            key={index}
            onClick={action.action}
            className="flex items-center space-x-4 p-4 rounded-lg border border-border hover:border-primary/50 hover:shadow-md transition-all duration-200 text-left"
          >
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center relative ${action.color}`}>
              <Icon name={action.icon} size={20} />
              {action.badge && (
                <span className="absolute -top-2 -right-2 w-5 h-5 bg-error text-error-foreground text-xs font-medium rounded-full flex items-center justify-center">
                  {action.badge}
                </span>
              )}
            </div>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-foreground mb-1">{action.title}</h3>
              <p className="text-sm text-muted-foreground line-clamp-2">{action.description}</p>
            </div>
            
            <Icon name="ChevronRight" size={16} className="text-muted-foreground flex-shrink-0" />
          </button>
        ))}
      </div>
      
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium text-foreground mb-1">Need Help?</h3>
            <p className="text-sm text-muted-foreground">Contact our support team for assistance</p>
          </div>
          <Button variant="outline" size="sm">
            <Icon name="MessageCircle" size={16} className="mr-2" />
            Chat Support
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;