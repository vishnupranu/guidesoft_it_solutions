import React from 'react';
import Icon from '../../../components/AppIcon';

const WelcomeHeader = ({ student }) => {
  const getCurrentGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="bg-gradient-to-r from-primary to-accent rounded-lg p-6 text-white mb-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-2">
            {getCurrentGreeting()}, {student.firstName}! 👋
          </h1>
          <p className="text-white/90 mb-4">
            Ready to continue your learning journey?
          </p>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Icon name="Flame" size={20} />
              <span className="font-medium">{student.learningStreak} day streak</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Clock" size={20} />
              <span className="font-medium">{student.totalHours}h learned</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Award" size={20} />
              <span className="font-medium">{student.certificatesEarned} certificates</span>
            </div>
          </div>
        </div>
        <div className="hidden md:block">
          <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
            <Icon name="GraduationCap" size={40} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default WelcomeHeader;