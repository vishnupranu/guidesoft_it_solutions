import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const CourseCatalog = ({ availableCourses }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');

  const categoryOptions = [
    { value: 'all', label: 'All Categories' },
    { value: 'web-development', label: 'Web Development' },
    { value: 'mobile-development', label: 'Mobile Development' },
    { value: 'data-science', label: 'Data Science' },
    { value: 'cybersecurity', label: 'Cybersecurity' },
    { value: 'cloud-computing', label: 'Cloud Computing' }
  ];

  const levelOptions = [
    { value: 'all', label: 'All Levels' },
    { value: 'beginner', label: 'Beginner' },
    { value: 'intermediate', label: 'Intermediate' },
    { value: 'advanced', label: 'Advanced' }
  ];

  const filteredCourses = availableCourses.filter(course => {
    const categoryMatch = selectedCategory === 'all' || course.category === selectedCategory;
    const levelMatch = selectedLevel === 'all' || course.level === selectedLevel;
    return categoryMatch && levelMatch;
  });

  const getDifficultyColor = (level) => {
    switch (level) {
      case 'beginner': return 'text-success bg-success/10';
      case 'intermediate': return 'text-warning bg-warning/10';
      case 'advanced': return 'text-error bg-error/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Course Catalog</h2>
        <div className="flex items-center space-x-4">
          <Select
            options={categoryOptions}
            value={selectedCategory}
            onChange={setSelectedCategory}
            placeholder="Category"
            className="w-48"
          />
          <Select
            options={levelOptions}
            value={selectedLevel}
            onChange={setSelectedLevel}
            placeholder="Level"
            className="w-32"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => (
          <div key={course.id} className="bg-muted/30 rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200">
            <div className="relative h-40 overflow-hidden">
              <Image
                src={course.thumbnail}
                alt={course.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3">
                <span className={`px-2 py-1 rounded text-xs font-medium ${getDifficultyColor(course.level)}`}>
                  {course.level}
                </span>
              </div>
              <div className="absolute top-3 right-3 bg-black/70 text-white px-2 py-1 rounded text-xs">
                {course.duration}
              </div>
            </div>
            
            <div className="p-4">
              <h3 className="font-semibold text-foreground mb-2 line-clamp-2">{course.title}</h3>
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{course.description}</p>
              
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <Icon name="Users" size={14} />
                    <span>{course.enrolledStudents}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} />
                    <span>{course.rating}</span>
                  </div>
                </div>
                <div className="text-lg font-bold text-foreground">
                  {course.price === 0 ? 'Free' : `$${course.price}`}
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  By {course.instructor}
                </div>
                <Button variant="default" size="sm">
                  Enroll Now
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredCourses.length === 0 && (
        <div className="text-center py-12">
          <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No courses found</h3>
          <p className="text-muted-foreground">Try adjusting your filters to see more courses.</p>
        </div>
      )}
    </div>
  );
};

export default CourseCatalog;