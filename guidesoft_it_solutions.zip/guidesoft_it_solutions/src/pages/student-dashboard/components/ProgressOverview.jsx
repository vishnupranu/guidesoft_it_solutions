import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressOverview = ({ progressData }) => {
  const metrics = [
    {
      title: 'Courses Completed',
      value: progressData.completedCourses,
      total: progressData.totalCourses,
      icon: 'BookOpen',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      title: 'Overall Progress',
      value: `${progressData.overallProgress}%`,
      icon: 'TrendingUp',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      title: 'Certificates Earned',
      value: progressData.certificatesEarned,
      icon: 'Award',
      color: 'text-warning',
      bgColor: 'bg-warning/10'
    },
    {
      title: 'Upcoming Deadlines',
      value: progressData.upcomingDeadlines,
      icon: 'Calendar',
      color: 'text-error',
      bgColor: 'bg-error/10'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {metrics.map((metric, index) => (
        <div key={index} className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow duration-200">
          <div className="flex items-center justify-between mb-4">
            <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
              <Icon name={metric.icon} size={24} className={metric.color} />
            </div>
            {metric.total && (
              <div className="text-right">
                <div className="text-2xl font-bold text-foreground">{metric.value}</div>
                <div className="text-sm text-muted-foreground">of {metric.total}</div>
              </div>
            )}
            {!metric.total && (
              <div className="text-2xl font-bold text-foreground">{metric.value}</div>
            )}
          </div>
          <h3 className="text-sm font-medium text-muted-foreground">{metric.title}</h3>
          {metric.total && (
            <div className="mt-3">
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(metric.value / metric.total) * 100}%` }}
                ></div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default ProgressOverview;