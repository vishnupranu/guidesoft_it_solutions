import React from 'react';
import Input from '../../../components/ui/Input';

const BasicInfoStep = ({ formData, errors, onChange }) => {
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Basic Information</h2>
        <p className="text-muted-foreground mt-2">
          Let's start with your basic details
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          label="First Name"
          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={onChange}
          error={errors.firstName}
          placeholder="Enter your first name"
          required
        />
        <Input
          label="Last Name"
          type="text"
          name="lastName"
          value={formData.lastName}
          onChange={onChange}
          error={errors.lastName}
          placeholder="Enter your last name"
          required
        />
      </div>

      <Input
        label="Email Address"
        type="email"
        name="email"
        value={formData.email}
        onChange={onChange}
        error={errors.email}
        placeholder="Enter your email address"
        description="We'll use this for account verification and communications"
        required
      />

      <Input
        label="Password"
        type="password"
        name="password"
        value={formData.password}
        onChange={onChange}
        error={errors.password}
        placeholder="Create a strong password"
        description="Must be at least 8 characters with uppercase, lowercase, and numbers"
        required
      />

      <Input
        label="Confirm Password"
        type="password"
        name="confirmPassword"
        value={formData.confirmPassword}
        onChange={onChange}
        error={errors.confirmPassword}
        placeholder="Confirm your password"
        required
      />

      <div className="bg-muted/50 rounded-lg p-4 border border-border">
        <div className="flex items-start space-x-3">
          <div className="w-5 h-5 bg-primary/10 rounded-full flex items-center justify-center mt-0.5">
            <div className="w-2 h-2 bg-primary rounded-full" />
          </div>
          <div>
            <h4 className="text-sm font-medium text-foreground">Password Requirements</h4>
            <ul className="text-xs text-muted-foreground mt-1 space-y-1">
              <li>• At least 8 characters long</li>
              <li>• Contains uppercase and lowercase letters</li>
              <li>• Includes at least one number</li>
              <li>• May include special characters for extra security</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicInfoStep;