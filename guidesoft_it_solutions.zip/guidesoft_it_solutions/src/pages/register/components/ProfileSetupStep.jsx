import React from 'react';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';

const ProfileSetupStep = ({ formData, errors, onChange }) => {
  const studentInterests = [
    { value: 'web-development', label: 'Web Development' },
    { value: 'mobile-development', label: 'Mobile Development' },
    { value: 'data-science', label: 'Data Science & Analytics' },
    { value: 'cloud-computing', label: 'Cloud Computing' },
    { value: 'cybersecurity', label: 'Cybersecurity' },
    { value: 'ai-ml', label: 'Artificial Intelligence & Machine Learning' },
    { value: 'devops', label: 'DevOps & Infrastructure' },
    { value: 'ui-ux', label: 'UI/UX Design' },
    { value: 'database', label: 'Database Management' },
    { value: 'networking', label: 'Networking' }
  ];

  const experienceLevels = [
    { value: 'beginner', label: 'Beginner (0-1 years)' },
    { value: 'intermediate', label: 'Intermediate (2-4 years)' },
    { value: 'advanced', label: 'Advanced (5-8 years)' },
    { value: 'expert', label: 'Expert (9+ years)' }
  ];

  const trainerExpertise = [
    { value: 'frontend', label: 'Frontend Development' },
    { value: 'backend', label: 'Backend Development' },
    { value: 'fullstack', label: 'Full Stack Development' },
    { value: 'mobile', label: 'Mobile Development' },
    { value: 'data-science', label: 'Data Science' },
    { value: 'cloud', label: 'Cloud Technologies' },
    { value: 'security', label: 'Cybersecurity' },
    { value: 'ai-ml', label: 'AI/ML' },
    { value: 'devops', label: 'DevOps' },
    { value: 'design', label: 'UI/UX Design' }
  ];

  const certifications = [
    { value: 'aws', label: 'AWS Certified' },
    { value: 'azure', label: 'Microsoft Azure Certified' },
    { value: 'google-cloud', label: 'Google Cloud Certified' },
    { value: 'cisco', label: 'Cisco Certified' },
    { value: 'comptia', label: 'CompTIA Certified' },
    { value: 'pmp', label: 'PMP Certified' },
    { value: 'scrum', label: 'Scrum Master Certified' },
    { value: 'other', label: 'Other Professional Certifications' }
  ];

  const handleCheckboxChange = (name, value, checked) => {
    const currentValues = formData[name] || [];
    const newValues = checked
      ? [...currentValues, value]
      : currentValues.filter(v => v !== value);
    
    onChange({ target: { name, value: newValues } });
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground">Complete Your Profile</h2>
        <p className="text-muted-foreground mt-2">
          {formData.role === 'student' ?'Tell us about your learning goals and interests' :'Share your expertise and qualifications'
          }
        </p>
      </div>

      {formData.role === 'student' ? (
        <div className="space-y-6">
          <Select
            label="Experience Level"
            description="What's your current experience level in IT?"
            options={experienceLevels}
            value={formData.experienceLevel}
            onChange={(value) => onChange({ target: { name: 'experienceLevel', value } })}
            error={errors.experienceLevel}
            required
          />

          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Areas of Interest <span className="text-error">*</span>
            </label>
            <p className="text-xs text-muted-foreground mb-4">
              Select the technologies and fields you're most interested in learning
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {studentInterests.map((interest) => (
                <Checkbox
                  key={interest.value}
                  label={interest.label}
                  checked={(formData.interests || []).includes(interest.value)}
                  onChange={(e) => handleCheckboxChange('interests', interest.value, e.target.checked)}
                />
              ))}
            </div>
            {errors.interests && (
              <p className="text-sm text-error mt-2">{errors.interests}</p>
            )}
          </div>

          <div className="bg-muted/50 rounded-lg p-4 border border-border">
            <div className="flex items-start space-x-3">
              <Icon name="Target" size={20} className="text-primary mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-foreground">Personalized Learning Path</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Based on your selections, we'll recommend courses and create a customized learning path 
                  that matches your experience level and interests.
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <Select
            label="Years of Experience"
            description="How many years of professional experience do you have?"
            options={experienceLevels}
            value={formData.experienceLevel}
            onChange={(value) => onChange({ target: { name: 'experienceLevel', value } })}
            error={errors.experienceLevel}
            required
          />

          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Areas of Expertise <span className="text-error">*</span>
            </label>
            <p className="text-xs text-muted-foreground mb-4">
              Select the areas where you have teaching or professional expertise
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {trainerExpertise.map((expertise) => (
                <Checkbox
                  key={expertise.value}
                  label={expertise.label}
                  checked={(formData.expertise || []).includes(expertise.value)}
                  onChange={(e) => handleCheckboxChange('expertise', expertise.value, e.target.checked)}
                />
              ))}
            </div>
            {errors.expertise && (
              <p className="text-sm text-error mt-2">{errors.expertise}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-3">
              Professional Certifications
            </label>
            <p className="text-xs text-muted-foreground mb-4">
              Select any relevant certifications you hold (optional)
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {certifications.map((cert) => (
                <Checkbox
                  key={cert.value}
                  label={cert.label}
                  checked={(formData.certifications || []).includes(cert.value)}
                  onChange={(e) => handleCheckboxChange('certifications', cert.value, e.target.checked)}
                />
              ))}
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg p-4 border border-border">
            <div className="flex items-start space-x-3">
              <Icon name="Award" size={20} className="text-primary mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-medium text-foreground">Trainer Verification</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  Our team will review your qualifications and expertise before approving your trainer account. 
                  This process typically takes 1-2 business days.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4 pt-4 border-t border-border">
        <Checkbox
          label={
            <span className="text-sm">
              I agree to the{' '}
              <a href="#terms" className="text-primary hover:text-primary/80 underline">
                Terms of Service
              </a>{' '}
              and{' '}
              <a href="#privacy" className="text-primary hover:text-primary/80 underline">
                Privacy Policy
              </a>
            </span>
          }
          checked={formData.agreeToTerms}
          onChange={(e) => onChange({ target: { name: 'agreeToTerms', value: e.target.checked } })}
          error={errors.agreeToTerms}
          required
        />

        <Checkbox
          label="I would like to receive updates about new courses and platform features"
          checked={formData.marketingEmails}
          onChange={(e) => onChange({ target: { name: 'marketingEmails', value: e.target.checked } })}
        />
      </div>
    </div>
  );
};

export default ProfileSetupStep;