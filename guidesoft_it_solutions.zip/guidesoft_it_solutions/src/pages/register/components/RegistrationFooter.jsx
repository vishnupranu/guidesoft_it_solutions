import React from 'react';
import { Link } from 'react-router-dom';

const RegistrationFooter = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="mt-12 pb-8">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-6 text-sm text-muted-foreground">
          <Link to="#terms" className="hover:text-foreground transition-colors duration-200">
            Terms of Service
          </Link>
          <Link to="#privacy" className="hover:text-foreground transition-colors duration-200">
            Privacy Policy
          </Link>
          <Link to="#support" className="hover:text-foreground transition-colors duration-200">
            Support
          </Link>
        </div>
        <div className="text-xs text-muted-foreground">
          <p>© {currentYear} Guidesoft IT Solutions. All rights reserved.</p>
          <p className="mt-1">Empowering IT professionals through quality education and training.</p>
        </div>
      </div>
    </footer>
  );
};

export default RegistrationFooter;