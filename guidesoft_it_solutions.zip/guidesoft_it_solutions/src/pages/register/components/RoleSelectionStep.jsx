import React from 'react';
import Icon from '../../../components/AppIcon';

const RoleSelectionStep = ({ formData, onChange }) => {
  const roles = [
    {
      value: 'student',
      title: 'Student',
      description: 'Learn new skills and advance your IT career',
      features: [
        'Access to all courses and learning materials',
        'Track your progress and achievements',
        'Interactive assignments and projects',
        'Certificate upon course completion',
        'Community forums and peer support'
      ],
      icon: 'GraduationCap',
      color: 'bg-blue-500'
    },
    {
      value: 'trainer',
      title: 'Trainer',
      description: 'Share your expertise and teach others',
      features: [
        'Create and manage your own courses',
        'Monitor student progress and engagement',
        'Access to content creation tools',
        'Analytics and reporting dashboard',
        'Direct communication with students'
      ],
      icon: 'Users',
      color: 'bg-emerald-500'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-foreground">Choose Your Role</h2>
        <p className="text-muted-foreground mt-2">
          Select how you'd like to use our platform
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {roles.map((role) => (
          <div
            key={role.value}
            onClick={() => onChange({ target: { name: 'role', value: role.value } })}
            className={`relative p-6 rounded-lg border-2 cursor-pointer transition-all duration-300 hover:shadow-lg ${
              formData.role === role.value
                ? 'border-primary bg-primary/5 shadow-md'
                : 'border-border hover:border-primary/50'
            }`}
          >
            <div className="flex items-center space-x-4 mb-4">
              <div className={`w-12 h-12 ${role.color} rounded-lg flex items-center justify-center`}>
                <Icon name={role.icon} size={24} color="white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">{role.title}</h3>
                <p className="text-sm text-muted-foreground">{role.description}</p>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-foreground">What you'll get:</h4>
              <ul className="space-y-1">
                {role.features.map((feature, index) => (
                  <li key={index} className="flex items-start space-x-2 text-sm text-muted-foreground">
                    <Icon name="Check" size={14} className="text-success mt-0.5 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            {formData.role === role.value && (
              <div className="absolute top-4 right-4">
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="Check" size={14} color="white" />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="bg-muted/50 rounded-lg p-4 border border-border">
        <div className="flex items-start space-x-3">
          <Icon name="Info" size={20} className="text-primary mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="text-sm font-medium text-foreground">Need to switch roles later?</h4>
            <p className="text-xs text-muted-foreground mt-1">
              You can contact our support team to change your role after registration. 
              However, some features may require additional verification.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoleSelectionStep;