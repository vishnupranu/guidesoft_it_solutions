import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import RegistrationHeader from './components/RegistrationHeader';
import RegistrationProgress from './components/RegistrationProgress';
import BasicInfoStep from './components/BasicInfoStep';
import RoleSelectionStep from './components/RoleSelectionStep';
import ProfileSetupStep from './components/ProfileSetupStep';
import RegistrationFooter from './components/RegistrationFooter';

const Register = () => {
  const navigate = useNavigate();
  const { signUp, authError, clearError } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'student',
    experienceLevel: '',
    interests: [],
    expertise: [],
    certifications: [],
    agreeToTerms: false,
    marketingEmails: false
  });
  const [errors, setErrors] = useState({});

  const totalSteps = 3;

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
    
    // Clear auth error when user starts typing
    if (authError) {
      clearError();
    }
  };

  const validateStep = (step) => {
    const newErrors = {};

    if (step === 1) {
      if (!formData.firstName.trim()) {
        newErrors.firstName = 'First name is required';
      }
      if (!formData.lastName.trim()) {
        newErrors.lastName = 'Last name is required';
      }
      if (!formData.email.trim()) {
        newErrors.email = 'Email is required';
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = 'Please enter a valid email address';
      }
      if (!formData.password) {
        newErrors.password = 'Password is required';
      } else if (formData.password.length < 8) {
        newErrors.password = 'Password must be at least 8 characters';
      } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
        newErrors.password = 'Password must contain uppercase, lowercase, and numbers';
      }
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }
    }

    if (step === 3) {
      if (!formData.experienceLevel) {
        newErrors.experienceLevel = 'Please select your experience level';
      }
      if (formData.role === 'student' && (!formData.interests || formData.interests.length === 0)) {
        newErrors.interests = 'Please select at least one area of interest';
      }
      if (formData.role === 'trainer' && (!formData.expertise || formData.expertise.length === 0)) {
        newErrors.expertise = 'Please select at least one area of expertise';
      }
      if (!formData.agreeToTerms) {
        newErrors.agreeToTerms = 'You must agree to the terms and conditions';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      if (currentStep < totalSteps) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep(currentStep)) {
      return;
    }

    setIsLoading(true);
    
    try {
      const result = await signUp(formData.email, formData.password, {
        firstName: formData.firstName,
        lastName: formData.lastName,
        role: formData.role,
        experienceLevel: formData.experienceLevel,
        interests: formData.interests,
        expertise: formData.expertise,
        certifications: formData.certifications,
        marketingEmails: formData.marketingEmails
      });
      
      if (result?.success) {
        // Navigate to appropriate dashboard based on role
        if (formData.role === 'student') {
          navigate('/student-dashboard');
        } else if (formData.role === 'trainer') {
          navigate('/trainer-dashboard');
        } else if (formData.role === 'admin') {
          navigate('/admin-control-panel');
        }
      }
    } catch (error) {
      console.log('Registration error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <BasicInfoStep
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
          />
        );
      case 2:
        return (
          <RoleSelectionStep
            formData={formData}
            onChange={handleInputChange}
          />
        );
      case 3:
        return (
          <ProfileSetupStep
            formData={formData}
            errors={errors}
            onChange={handleInputChange}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      <RegistrationHeader />
      
      <div className="pt-20 pb-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Registration Card */}
          <div className="bg-card border border-border rounded-xl shadow-lg p-8">
            <RegistrationProgress currentStep={currentStep} totalSteps={totalSteps} />
            
            {/* Step Content */}
            <div className="mb-8">
              {renderStepContent()}
            </div>

            {/* Error Message */}
            {authError && (
              <div className="mb-6 p-4 bg-error/10 border border-error/20 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Icon name="AlertCircle" size={16} className="text-error" />
                  <p className="text-sm text-error">{authError}</p>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex items-center justify-between">
              <Button
                variant="outline"
                onClick={handleBack}
                disabled={currentStep === 1}
                iconName="ChevronLeft"
                iconPosition="left"
              >
                Back
              </Button>

              <div className="flex items-center space-x-3">
                {currentStep < totalSteps ? (
                  <Button
                    variant="default"
                    onClick={handleNext}
                    iconName="ChevronRight"
                    iconPosition="right"
                  >
                    Next Step
                  </Button>
                ) : (
                  <Button
                    variant="default"
                    onClick={handleSubmit}
                    loading={isLoading}
                    disabled={isLoading}
                    iconName="UserPlus"
                    iconPosition="left"
                  >
                    Create Account
                  </Button>
                )}
              </div>
            </div>

            {/* Step Indicator */}
            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                Step {currentStep} of {totalSteps}
              </p>
            </div>
          </div>

          <RegistrationFooter />
        </div>
      </div>
    </div>
  );
};

export default Register;