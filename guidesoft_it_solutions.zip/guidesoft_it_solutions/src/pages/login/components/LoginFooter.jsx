import React from 'react';
import { Link } from 'react-router-dom';

const LoginFooter = () => {
  const currentYear = new Date().getFullYear();

  return (
    <div className="mt-8 space-y-4">
      {/* Switch to Register */}
      <div className="text-center">
        <p className="text-sm text-slate-600">
          Don't have an account?{' '}
          <Link
            to="/register"
            className="text-blue-600 hover:text-blue-800 font-medium transition-colors duration-200"
          >
            Create account
          </Link>
        </p>
      </div>

      {/* Back to Website */}
      <div className="text-center">
        <Link
          to="/home-page"
          className="inline-flex items-center text-sm text-slate-500 hover:text-slate-700 transition-colors duration-200"
        >
          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Website
        </Link>
      </div>

      {/* Copyright */}
      <div className="text-center text-xs text-slate-500">
        <p>© {currentYear} Guidesoft IT Solutions. All rights reserved.</p>
      </div>
    </div>
  );
};

export default LoginFooter;