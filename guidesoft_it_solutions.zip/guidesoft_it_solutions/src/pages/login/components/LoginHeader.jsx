import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const LoginHeader = () => {
  return (
    <div className="text-center mb-8">
      <Link to="/home-page" className="inline-flex items-center space-x-2 mb-6">
        <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
          <Icon name="Code2" size={24} color="white" />
        </div>
        <span className="text-2xl font-bold text-slate-900">
          Guidesoft IT Solutions
        </span>
      </Link>
      
      <h1 className="text-3xl font-bold text-slate-900 mb-2">
        Welcome Back
      </h1>
      <p className="text-slate-600">
        Sign in to access your learning dashboard
      </p>
    </div>
  );
};

export default LoginHeader;