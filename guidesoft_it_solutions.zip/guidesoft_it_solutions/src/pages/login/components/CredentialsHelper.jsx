import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CredentialsHelper = () => {
  const [isExpanded, setIsExpanded] = useState(false);

  const credentials = [
    {
      role: 'Student',
      email: 'student@guidesoft.com',
      password: 'student123',
      description: 'Access student dashboard with course materials and progress tracking'
    },
    {
      role: 'Trainer',
      email: 'trainer@guidesoft.com',
      password: 'trainer123',
      description: 'Access trainer dashboard with content management and student oversight'
    },
    {
      role: 'Administrator',
      email: 'admin@guidesoft.com',
      password: 'admin123',
      description: 'Access admin control panel with full platform management'
    }
  ];

  return (
    <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between w-full text-left"
      >
        <div className="flex items-center space-x-2">
          <Icon name="Info" size={16} className="text-blue-600" />
          <span className="text-sm font-medium text-blue-800">Demo Credentials</span>
        </div>
        <Icon 
          name={isExpanded ? "ChevronUp" : "ChevronDown"} 
          size={16} 
          className="text-blue-600" 
        />
      </button>
      
      {isExpanded && (
        <div className="mt-4 space-y-3">
          {credentials.map((cred, index) => (
            <div key={index} className="p-3 bg-white rounded border border-blue-100">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-slate-900">{cred.role}</h4>
                <Button
                  variant="ghost"
                  size="xs"
                  onClick={() => {
                    navigator.clipboard.writeText(`${cred.email} / ${cred.password}`);
                  }}
                >
                  <Icon name="Copy" size={14} />
                </Button>
              </div>
              <div className="text-xs text-slate-600 space-y-1">
                <p><strong>Email:</strong> {cred.email}</p>
                <p><strong>Password:</strong> {cred.password}</p>
                <p className="text-slate-500">{cred.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CredentialsHelper;