import React from 'react';
import LoginHeader from './components/LoginHeader';
import LoginForm from './components/LoginForm';
import SocialLogin from './components/SocialLogin';
import LoginFooter from './components/LoginFooter';
import CredentialsHelper from './components/CredentialsHelper';

const LoginPage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Header with Logo and Title */}
        <LoginHeader />

        {/* Main Login Card */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-lg p-8">
          {/* Login Form */}
          <LoginForm />

          {/* Social Login Options */}
          <SocialLogin />
        </div>

        {/* Demo Credentials Helper */}
        <CredentialsHelper />

        {/* Footer Links */}
        <LoginFooter />
      </div>
    </div>
  );
};

export default LoginPage;