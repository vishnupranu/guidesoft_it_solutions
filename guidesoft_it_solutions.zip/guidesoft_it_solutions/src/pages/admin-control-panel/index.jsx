import React, { useState } from 'react';
import AuthenticatedHeader from '../../components/ui/AuthenticatedHeader';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import SystemHealthCard from './components/SystemHealthCard';
import UserManagementTable from './components/UserManagementTable';
import ContentManagementPanel from './components/ContentManagementPanel';
import AnalyticsChart from './components/AnalyticsChart';
import SystemConfigPanel from './components/SystemConfigPanel';
import SecurityMonitor from './components/SecurityMonitor';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const AdminControlPanel = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeView, setActiveView] = useState('overview');

  // Mock admin user data
  const adminUser = {
    name: 'Admin User',
    email: 'admin@guidesoft.com',
    avatar: null,
    role: 'admin'
  };

  // Mock system health data
  const systemHealthData = [
    {
      title: 'Server Uptime',
      value: '99.9%',
      change: 0.1,
      status: 'excellent',
      icon: 'Server',
      color: 'bg-success'
    },
    {
      title: 'Active Users',
      value: '2,847',
      change: 12.5,
      status: 'good',
      icon: 'Users',
      color: 'bg-accent'
    },
    {
      title: 'System Load',
      value: '45%',
      change: -5.2,
      status: 'good',
      icon: 'Activity',
      color: 'bg-primary'
    },
    {
      title: 'Storage Used',
      value: '78%',
      change: 8.3,
      status: 'warning',
      icon: 'HardDrive',
      color: 'bg-warning'
    },
    {
      title: 'Response Time',
      value: '120ms',
      change: -15.8,
      status: 'excellent',
      icon: 'Zap',
      color: 'bg-success'
    },
    {
      title: 'Error Rate',
      value: '0.02%',
      change: -45.2,
      status: 'excellent',
      icon: 'AlertTriangle',
      color: 'bg-error'
    }
  ];

  // Mock users data
  const usersData = [
    {
      id: 1,
      name: 'John Smith',
      email: 'john.smith@example.com',
      role: 'student',
      status: 'active',
      lastActive: '2 hours ago',
      coursesCount: 3
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      email: 'sarah.johnson@example.com',
      role: 'trainer',
      status: 'active',
      lastActive: '30 minutes ago',
      coursesCount: 8
    },
    {
      id: 3,
      name: 'Mike Davis',
      email: 'mike.davis@example.com',
      role: 'student',
      status: 'inactive',
      lastActive: '1 week ago',
      coursesCount: 1
    },
    {
      id: 4,
      name: 'Emily Wilson',
      email: 'emily.wilson@example.com',
      role: 'admin',
      status: 'active',
      lastActive: '5 minutes ago',
      coursesCount: 0
    },
    {
      id: 5,
      name: 'David Brown',
      email: 'david.brown@example.com',
      role: 'student',
      status: 'suspended',
      lastActive: '3 days ago',
      coursesCount: 2
    }
  ];

  // Mock content data
  const contentData = {
    courses: [
      {
        id: 1,
        title: 'Advanced React Development',
        description: 'Comprehensive course covering advanced React concepts and patterns',
        author: 'Sarah Johnson',
        status: 'published',
        lastModified: '2 days ago',
        enrollments: 145,
        views: 1250
      },
      {
        id: 2,
        title: 'JavaScript Fundamentals',
        description: 'Complete guide to JavaScript programming for beginners',
        author: 'Mike Davis',
        status: 'draft',
        lastModified: '1 week ago',
        enrollments: 0,
        views: 0
      },
      {
        id: 3,
        title: 'Node.js Backend Development',
        description: 'Learn to build scalable backend applications with Node.js',
        author: 'John Smith',
        status: 'pending',
        lastModified: '3 days ago',
        enrollments: 0,
        views: 45
      }
    ],
    blog: [
      {
        id: 1,
        title: 'The Future of Web Development',
        description: 'Exploring upcoming trends and technologies in web development',
        author: 'Admin User',
        status: 'published',
        lastModified: '1 day ago',
        views: 2340
      },
      {
        id: 2,
        title: 'Best Practices for React Applications',
        description: 'Essential guidelines for building maintainable React apps',
        author: 'Sarah Johnson',
        status: 'draft',
        lastModified: '4 days ago',
        views: 0
      }
    ],
    pages: [
      {
        id: 1,
        title: 'About Us',
        description: 'Company information and team details',
        author: 'Admin User',
        status: 'published',
        lastModified: '1 week ago',
        views: 890
      },
      {
        id: 2,
        title: 'Services',
        description: 'Detailed overview of our service offerings',
        author: 'Admin User',
        status: 'published',
        lastModified: '2 weeks ago',
        views: 1560
      }
    ],
    resources: [
      {
        id: 1,
        title: 'JavaScript Cheat Sheet',
        description: 'Quick reference guide for JavaScript syntax and methods',
        author: 'Mike Davis',
        status: 'published',
        lastModified: '5 days ago',
        views: 3450
      }
    ]
  };

  // Mock analytics data
  const analyticsData = [
    { name: 'Jan', value: 1200 },
    { name: 'Feb', value: 1900 },
    { name: 'Mar', value: 1600 },
    { name: 'Apr', value: 2400 },
    { name: 'May', value: 2100 },
    { name: 'Jun', value: 2800 },
    { name: 'Jul', value: 3200 }
  ];

  const courseAnalyticsData = [
    { name: 'React', value: 450 },
    { name: 'JavaScript', value: 380 },
    { name: 'Node.js', value: 290 },
    { name: 'Python', value: 220 },
    { name: 'CSS', value: 180 }
  ];

  const userEngagementData = [
    { name: 'Week 1', value: 85 },
    { name: 'Week 2', value: 92 },
    { name: 'Week 3', value: 78 },
    { name: 'Week 4', value: 88 },
    { name: 'Week 5', value: 95 },
    { name: 'Week 6', value: 89 },
    { name: 'Week 7', value: 93 }
  ];

  const viewOptions = [
    { id: 'overview', label: 'Overview', icon: 'LayoutDashboard' },
    { id: 'users', label: 'User Management', icon: 'Users' },
    { id: 'content', label: 'Content Management', icon: 'FileText' },
    { id: 'analytics', label: 'Analytics', icon: 'BarChart3' },
    { id: 'settings', label: 'System Settings', icon: 'Settings' },
    { id: 'security', label: 'Security Monitor', icon: 'Shield' }
  ];

  const handleUserAction = (action, userId) => {
    console.log(`${action} action for user ${userId}`);
  };

  const handleContentAction = (action, contentId) => {
    console.log(`${action} action for content ${contentId}`);
  };

  const handleSettingsUpdate = (settings) => {
    console.log('Settings updated:', settings);
  };

  const renderMainContent = () => {
    switch (activeView) {
      case 'overview':
        return (
          <div className="space-y-8">
            {/* System Health Cards */}
            <div>
              <h2 className="text-xl font-semibold text-foreground mb-6">System Health Overview</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {systemHealthData.map((metric, index) => (
                  <SystemHealthCard key={index} {...metric} />
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <AnalyticsChart
                data={analyticsData}
                title="User Growth"
                type="line"
              />
              <AnalyticsChart
                data={courseAnalyticsData}
                title="Popular Courses"
                type="pie"
              />
            </div>

            {/* Recent Activity */}
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">Recent Platform Activity</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-3 bg-muted/30 rounded-lg">
                  <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center">
                    <Icon name="UserPlus" size={16} color="white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">New user registered</p>
                    <p className="text-xs text-muted-foreground">john.doe@example.com joined the platform</p>
                  </div>
                  <span className="text-xs text-muted-foreground">5 minutes ago</span>
                </div>

                <div className="flex items-center space-x-4 p-3 bg-muted/30 rounded-lg">
                  <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                    <Icon name="BookOpen" size={16} color="white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">Course published</p>
                    <p className="text-xs text-muted-foreground">Advanced React Development is now live</p>
                  </div>
                  <span className="text-xs text-muted-foreground">2 hours ago</span>
                </div>

                <div className="flex items-center space-x-4 p-3 bg-muted/30 rounded-lg">
                  <div className="w-8 h-8 bg-warning rounded-full flex items-center justify-center">
                    <Icon name="AlertTriangle" size={16} color="white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">System maintenance scheduled</p>
                    <p className="text-xs text-muted-foreground">Maintenance window: Tomorrow 2:00 AM - 4:00 AM</p>
                  </div>
                  <span className="text-xs text-muted-foreground">1 day ago</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'users':
        return (
          <UserManagementTable
            users={usersData}
            onUserAction={handleUserAction}
          />
        );

      case 'content':
        return (
          <ContentManagementPanel
            content={contentData}
            onContentAction={handleContentAction}
          />
        );

      case 'analytics':
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <AnalyticsChart
                data={analyticsData}
                title="Monthly User Growth"
                type="bar"
              />
              <AnalyticsChart
                data={userEngagementData}
                title="User Engagement Rate"
                type="line"
              />
            </div>
            <AnalyticsChart
              data={courseAnalyticsData}
              title="Course Enrollment Distribution"
              type="pie"
            />
          </div>
        );

      case 'settings':
        return (
          <SystemConfigPanel
            settings={{}}
            onSettingsUpdate={handleSettingsUpdate}
          />
        );

      case 'security':
        return (
          <SecurityMonitor
            securityData={{}}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthenticatedHeader user={adminUser} />
      
      <div className="flex">
        <RoleBasedSidebar
          user={adminUser}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
        
        <main className={`flex-1 transition-all duration-300 ${
          sidebarCollapsed ? 'ml-16' : 'ml-64'
        } pt-16`}>
          <div className="p-6">
            {/* Page Header */}
            <div className="mb-8">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Admin Control Panel</h1>
                  <p className="text-muted-foreground mt-2">
                    Comprehensive platform oversight and management
                  </p>
                </div>
                
                <div className="flex items-center space-x-4">
                  <Button variant="outline" iconName="Download" iconPosition="left">
                    Export Data
                  </Button>
                  <Button variant="default" iconName="Plus" iconPosition="left">
                    Quick Action
                  </Button>
                </div>
              </div>

              {/* View Navigation */}
              <div className="mt-6 flex flex-wrap gap-2">
                {viewOptions.map((option) => (
                  <button
                    key={option.id}
                    onClick={() => setActiveView(option.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      activeView === option.id
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                    }`}
                  >
                    <Icon name={option.icon} size={16} />
                    <span>{option.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Main Content */}
            {renderMainContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminControlPanel;