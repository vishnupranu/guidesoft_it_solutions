import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const ContentManagementPanel = ({ content, onContentAction }) => {
  const [activeTab, setActiveTab] = useState('courses');
  const [statusFilter, setStatusFilter] = useState('all');

  const tabs = [
    { id: 'courses', label: 'Courses', icon: 'BookOpen', count: content.courses?.length || 0 },
    { id: 'blog', label: 'Blog Posts', icon: 'FileText', count: content.blog?.length || 0 },
    { id: 'pages', label: 'Website Pages', icon: 'Globe', count: content.pages?.length || 0 },
    { id: 'resources', label: 'Resources', icon: 'Library', count: content.resources?.length || 0 }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'published', label: 'Published' },
    { value: 'draft', label: 'Draft' },
    { value: 'pending', label: 'Pending Review' },
    { value: 'archived', label: 'Archived' }
  ];

  const getStatusBadge = (status) => {
    const statusConfig = {
      published: { color: 'bg-success/10 text-success', label: 'Published' },
      draft: { color: 'bg-muted text-muted-foreground', label: 'Draft' },
      pending: { color: 'bg-warning/10 text-warning', label: 'Pending Review' },
      archived: { color: 'bg-error/10 text-error', label: 'Archived' }
    };

    const config = statusConfig[status] || statusConfig.draft;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const getCurrentContent = () => {
    const currentContent = content[activeTab] || [];
    if (statusFilter === 'all') return currentContent;
    return currentContent.filter(item => item.status === statusFilter);
  };

  const renderContentItem = (item) => {
    return (
      <div key={item.id} className="p-4 border border-border rounded-lg hover:shadow-sm transition-shadow duration-200">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="text-sm font-medium text-foreground mb-1">{item.title}</h3>
            <p className="text-xs text-muted-foreground line-clamp-2">{item.description}</p>
          </div>
          <div className="ml-4 flex items-center space-x-2">
            {getStatusBadge(item.status)}
            <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <div className="flex items-center space-x-4">
            <span>By {item.author}</span>
            <span>{item.lastModified}</span>
            {item.views && <span>{item.views} views</span>}
            {item.enrollments && <span>{item.enrollments} enrolled</span>}
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" iconName="Eye">
              Preview
            </Button>
            <Button variant="ghost" size="sm" iconName="Edit">
              Edit
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div>
            <h2 className="text-lg font-semibold text-foreground">Content Management</h2>
            <p className="text-sm text-muted-foreground">
              Manage all platform content and publishing workflows
            </p>
          </div>
          
          <div className="flex items-center space-x-3">
            <Select
              options={statusOptions}
              value={statusFilter}
              onChange={setStatusFilter}
              placeholder="Filter by status"
            />
            <Button variant="default" iconName="Plus" iconPosition="left">
              Create Content
            </Button>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-6 flex flex-wrap gap-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={tab.icon} size={16} />
              <span>{tab.label}</span>
              <span className={`px-2 py-0.5 rounded-full text-xs ${
                activeTab === tab.id
                  ? 'bg-primary-foreground/20 text-primary-foreground'
                  : 'bg-muted text-muted-foreground'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Content Grid */}
      <div className="p-6">
        {getCurrentContent().length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {getCurrentContent().map(renderContentItem)}
          </div>
        ) : (
          <div className="text-center py-12">
            <Icon name="FileX" size={48} className="mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">No content found</h3>
            <p className="text-sm text-muted-foreground mb-4">
              {statusFilter === 'all' 
                ? `No ${activeTab} available yet.`
                : `No ${activeTab} with ${statusFilter} status.`
              }
            </p>
            <Button variant="default" iconName="Plus" iconPosition="left">
              Create {activeTab.slice(0, -1)}
            </Button>
          </div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <span>Quick Actions:</span>
            <Button variant="ghost" size="sm" iconName="Upload">
              Bulk Upload
            </Button>
            <Button variant="ghost" size="sm" iconName="Download">
              Export All
            </Button>
            <Button variant="ghost" size="sm" iconName="Archive">
              Archive Selected
            </Button>
          </div>
          
          <div className="text-sm text-muted-foreground">
            Total: {getCurrentContent().length} items
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentManagementPanel;