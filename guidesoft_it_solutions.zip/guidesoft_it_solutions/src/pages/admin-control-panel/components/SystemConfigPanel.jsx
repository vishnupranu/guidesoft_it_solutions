import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';

const SystemConfigPanel = ({ settings, onSettingsUpdate }) => {
  const [activeSection, setActiveSection] = useState('general');
  const [unsavedChanges, setUnsavedChanges] = useState(false);

  const sections = [
    { id: 'general', label: 'General Settings', icon: 'Settings' },
    { id: 'security', label: 'Security', icon: 'Shield' },
    { id: 'notifications', label: 'Notifications', icon: 'Bell' },
    { id: 'integrations', label: 'Integrations', icon: 'Plug' },
    { id: 'maintenance', label: 'Maintenance', icon: 'Wrench' }
  ];

  const handleSettingChange = (key, value) => {
    setUnsavedChanges(true);
    // Handle setting change logic here
  };

  const handleSaveSettings = () => {
    setUnsavedChanges(false);
    // Handle save logic here
  };

  const renderGeneralSettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Input
          label="Platform Name"
          value="Guidesoft IT Solutions"
          onChange={(e) => handleSettingChange('platformName', e.target.value)}
          description="The name displayed across the platform"
        />
        <Input
          label="Support Email"
          type="email"
          value="support@guidesoft.com"
          onChange={(e) => handleSettingChange('supportEmail', e.target.value)}
          description="Primary contact email for support"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Select
          label="Default Language"
          options={[
            { value: 'en', label: 'English' },
            { value: 'es', label: 'Spanish' },
            { value: 'fr', label: 'French' }
          ]}
          value="en"
          onChange={(value) => handleSettingChange('defaultLanguage', value)}
        />
        <Select
          label="Timezone"
          options={[
            { value: 'UTC', label: 'UTC' },
            { value: 'EST', label: 'Eastern Time' },
            { value: 'PST', label: 'Pacific Time' }
          ]}
          value="UTC"
          onChange={(value) => handleSettingChange('timezone', value)}
        />
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">Platform Features</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Checkbox
            label="Enable user registration"
            checked
            onChange={(e) => handleSettingChange('enableRegistration', e.target.checked)}
          />
          <Checkbox
            label="Allow course reviews"
            checked
            onChange={(e) => handleSettingChange('allowReviews', e.target.checked)}
          />
          <Checkbox
            label="Enable discussion forums"
           
            onChange={(e) => handleSettingChange('enableForums', e.target.checked)}
          />
          <Checkbox
            label="Allow file uploads"
            checked
            onChange={(e) => handleSettingChange('allowUploads', e.target.checked)}
          />
        </div>
      </div>
    </div>
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Input
          label="Session Timeout (minutes)"
          type="number"
          value="30"
          onChange={(e) => handleSettingChange('sessionTimeout', e.target.value)}
          description="Automatic logout after inactivity"
        />
        <Input
          label="Max Login Attempts"
          type="number"
          value="5"
          onChange={(e) => handleSettingChange('maxLoginAttempts', e.target.value)}
          description="Account lockout threshold"
        />
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">Security Features</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Checkbox
            label="Require two-factor authentication"
           
            onChange={(e) => handleSettingChange('require2FA', e.target.checked)}
          />
          <Checkbox
            label="Enable password complexity rules"
            checked
            onChange={(e) => handleSettingChange('passwordComplexity', e.target.checked)}
          />
          <Checkbox
            label="Log security events"
            checked
            onChange={(e) => handleSettingChange('logSecurityEvents', e.target.checked)}
          />
          <Checkbox
            label="Enable IP whitelisting"
           
            onChange={(e) => handleSettingChange('ipWhitelisting', e.target.checked)}
          />
        </div>
      </div>

      <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="AlertTriangle" size={20} className="text-warning mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-foreground">Security Notice</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Changes to security settings will affect all users. Please review carefully before saving.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">Email Notifications</h4>
        <div className="space-y-3">
          <Checkbox
            label="New user registrations"
            checked
            onChange={(e) => handleSettingChange('notifyNewUsers', e.target.checked)}
          />
          <Checkbox
            label="Course completions"
            checked
            onChange={(e) => handleSettingChange('notifyCourseCompletions', e.target.checked)}
          />
          <Checkbox
            label="System maintenance alerts"
            checked
            onChange={(e) => handleSettingChange('notifyMaintenance', e.target.checked)}
          />
          <Checkbox
            label="Security alerts"
            checked
            onChange={(e) => handleSettingChange('notifySecurityAlerts', e.target.checked)}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">Push Notifications</h4>
        <div className="space-y-3">
          <Checkbox
            label="Assignment due reminders"
            checked
            onChange={(e) => handleSettingChange('pushAssignmentReminders', e.target.checked)}
          />
          <Checkbox
            label="New course announcements"
           
            onChange={(e) => handleSettingChange('pushCourseAnnouncements', e.target.checked)}
          />
          <Checkbox
            label="Discussion replies"
           
            onChange={(e) => handleSettingChange('pushDiscussionReplies', e.target.checked)}
          />
        </div>
      </div>
    </div>
  );

  const renderIntegrationsSettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6">
        <div className="p-4 border border-border rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                <Icon name="Mail" size={20} color="white" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-foreground">Email Service</h4>
                <p className="text-xs text-muted-foreground">SMTP configuration for email delivery</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-1 bg-success/10 text-success text-xs font-medium rounded-full">
                Connected
              </span>
              <Button variant="outline" size="sm">Configure</Button>
            </div>
          </div>
        </div>

        <div className="p-4 border border-border rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-warning rounded-lg flex items-center justify-center">
                <Icon name="CreditCard" size={20} color="white" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-foreground">Payment Gateway</h4>
                <p className="text-xs text-muted-foreground">Stripe integration for course payments</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-1 bg-muted text-muted-foreground text-xs font-medium rounded-full">
                Not Connected
              </span>
              <Button variant="outline" size="sm">Setup</Button>
            </div>
          </div>
        </div>

        <div className="p-4 border border-border rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="BarChart3" size={20} color="white" />
              </div>
              <div>
                <h4 className="text-sm font-medium text-foreground">Analytics</h4>
                <p className="text-xs text-muted-foreground">Google Analytics integration</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <span className="px-2 py-1 bg-success/10 text-success text-xs font-medium rounded-full">
                Connected
              </span>
              <Button variant="outline" size="sm">Configure</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderMaintenanceSettings = () => (
    <div className="space-y-6">
      <div className="p-4 bg-error/10 border border-error/20 rounded-lg">
        <div className="flex items-start space-x-3">
          <Icon name="AlertCircle" size={20} className="text-error mt-0.5" />
          <div className="flex-1">
            <h4 className="text-sm font-medium text-foreground">Maintenance Mode</h4>
            <p className="text-sm text-muted-foreground mt-1">
              Enable maintenance mode to perform system updates. Users will see a maintenance page.
            </p>
            <div className="mt-4 flex items-center space-x-4">
              <Checkbox
                label="Enable maintenance mode"
               
                onChange={(e) => handleSettingChange('maintenanceMode', e.target.checked)}
              />
              <Button variant="outline" size="sm">
                Schedule Maintenance
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">System Cleanup</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 border border-border rounded-lg">
            <h5 className="text-sm font-medium text-foreground mb-2">Clear Cache</h5>
            <p className="text-xs text-muted-foreground mb-3">
              Clear system cache to improve performance
            </p>
            <Button variant="outline" size="sm" iconName="Trash2">
              Clear Cache
            </Button>
          </div>
          
          <div className="p-4 border border-border rounded-lg">
            <h5 className="text-sm font-medium text-foreground mb-2">Database Cleanup</h5>
            <p className="text-xs text-muted-foreground mb-3">
              Remove old logs and temporary data
            </p>
            <Button variant="outline" size="sm" iconName="Database">
              Cleanup Database
            </Button>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">Backup & Restore</h4>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-4 border border-border rounded-lg">
            <h5 className="text-sm font-medium text-foreground mb-2">Create Backup</h5>
            <p className="text-xs text-muted-foreground mb-3">
              Create a full system backup
            </p>
            <Button variant="default" size="sm" iconName="Download">
              Create Backup
            </Button>
          </div>
          
          <div className="p-4 border border-border rounded-lg">
            <h5 className="text-sm font-medium text-foreground mb-2">Restore System</h5>
            <p className="text-xs text-muted-foreground mb-3">
              Restore from a previous backup
            </p>
            <Button variant="outline" size="sm" iconName="Upload">
              Restore Backup
            </Button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'general':
        return renderGeneralSettings();
      case 'security':
        return renderSecuritySettings();
      case 'notifications':
        return renderNotificationSettings();
      case 'integrations':
        return renderIntegrationsSettings();
      case 'maintenance':
        return renderMaintenanceSettings();
      default:
        return renderGeneralSettings();
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div>
            <h2 className="text-lg font-semibold text-foreground">System Configuration</h2>
            <p className="text-sm text-muted-foreground">
              Manage platform settings and configurations
            </p>
          </div>
          
          {unsavedChanges && (
            <div className="flex items-center space-x-3">
              <span className="text-sm text-warning">Unsaved changes</span>
              <Button variant="outline" size="sm">
                Discard
              </Button>
              <Button variant="default" size="sm" onClick={handleSaveSettings}>
                Save Changes
              </Button>
            </div>
          )}
        </div>

        {/* Section Tabs */}
        <div className="mt-6 flex flex-wrap gap-2">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveSection(section.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                activeSection === section.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`}
            >
              <Icon name={section.icon} size={16} />
              <span>{section.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {renderSectionContent()}
      </div>
    </div>
  );
};

export default SystemConfigPanel;