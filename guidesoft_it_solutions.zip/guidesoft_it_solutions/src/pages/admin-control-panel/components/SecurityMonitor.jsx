import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const SecurityMonitor = ({ securityData }) => {
  const [timeFilter, setTimeFilter] = useState('24h');
  const [alertFilter, setAlertFilter] = useState('all');

  const timeOptions = [
    { value: '1h', label: 'Last Hour' },
    { value: '24h', label: 'Last 24 Hours' },
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' }
  ];

  const alertOptions = [
    { value: 'all', label: 'All Alerts' },
    { value: 'critical', label: 'Critical' },
    { value: 'warning', label: 'Warning' },
    { value: 'info', label: 'Info' }
  ];

  const securityAlerts = [
    {
      id: 1,
      type: 'critical',
      title: 'Multiple Failed Login Attempts',
      description: 'User account locked due to 5 consecutive failed login attempts',
      timestamp: '2 minutes ago',
      ip: '192.168.1.100',
      user: 'john.doe@example.com',
      action: 'Account Locked'
    },
    {
      id: 2,
      type: 'warning',
      title: 'Unusual Login Location',
      description: 'Login detected from new geographic location',
      timestamp: '15 minutes ago',
      ip: '203.0.113.45',
      user: 'sarah.smith@example.com',
      action: 'Location Verified'
    },
    {
      id: 3,
      type: 'info',
      title: 'Password Changed',
      description: 'User successfully changed their password',
      timestamp: '1 hour ago',
      ip: '192.168.1.50',
      user: 'mike.johnson@example.com',
      action: 'Password Updated'
    },
    {
      id: 4,
      type: 'critical',
      title: 'Suspicious API Activity',
      description: 'Unusual API request patterns detected',
      timestamp: '2 hours ago',
      ip: '198.51.100.25',
      user: 'System API',
      action: 'Rate Limited'
    }
  ];

  const loginAttempts = [
    {
      id: 1,
      user: 'admin@guidesoft.com',
      ip: '192.168.1.10',
      location: 'New York, US',
      status: 'success',
      timestamp: '5 minutes ago',
      device: 'Chrome on Windows'
    },
    {
      id: 2,
      user: 'trainer@guidesoft.com',
      ip: '192.168.1.20',
      location: 'California, US',
      status: 'success',
      timestamp: '12 minutes ago',
      device: 'Safari on macOS'
    },
    {
      id: 3,
      user: 'unknown@suspicious.com',
      ip: '203.0.113.100',
      location: 'Unknown',
      status: 'failed',
      timestamp: '18 minutes ago',
      device: 'Unknown'
    }
  ];

  const getAlertIcon = (type) => {
    switch (type) {
      case 'critical':
        return { name: 'AlertCircle', color: 'text-error' };
      case 'warning':
        return { name: 'AlertTriangle', color: 'text-warning' };
      case 'info':
        return { name: 'Info', color: 'text-accent' };
      default:
        return { name: 'Info', color: 'text-muted-foreground' };
    }
  };

  const getAlertBadge = (type) => {
    const config = {
      critical: { color: 'bg-error/10 text-error', label: 'Critical' },
      warning: { color: 'bg-warning/10 text-warning', label: 'Warning' },
      info: { color: 'bg-accent/10 text-accent', label: 'Info' }
    };

    const alertConfig = config[type] || config.info;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${alertConfig.color}`}>
        {alertConfig.label}
      </span>
    );
  };

  const getStatusBadge = (status) => {
    const config = {
      success: { color: 'bg-success/10 text-success', label: 'Success' },
      failed: { color: 'bg-error/10 text-error', label: 'Failed' },
      blocked: { color: 'bg-warning/10 text-warning', label: 'Blocked' }
    };

    const statusConfig = config[status] || config.failed;
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusConfig.color}`}>
        {statusConfig.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Security Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-error rounded-lg flex items-center justify-center">
              <Icon name="Shield" size={24} color="white" />
            </div>
            <span className="text-xs text-error font-medium">3 Critical</span>
          </div>
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Security Alerts</h3>
          <p className="text-2xl font-bold text-foreground">12</p>
          <p className="text-xs text-muted-foreground mt-1">Last 24 hours</p>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-warning rounded-lg flex items-center justify-center">
              <Icon name="UserX" size={24} color="white" />
            </div>
            <span className="text-xs text-warning font-medium">5 Failed</span>
          </div>
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Login Attempts</h3>
          <p className="text-2xl font-bold text-foreground">247</p>
          <p className="text-xs text-muted-foreground mt-1">98.2% success rate</p>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center">
              <Icon name="Users" size={24} color="white" />
            </div>
            <span className="text-xs text-success font-medium">+12 Today</span>
          </div>
          <h3 className="text-sm font-medium text-muted-foreground mb-1">Active Sessions</h3>
          <p className="text-2xl font-bold text-foreground">1,234</p>
          <p className="text-xs text-muted-foreground mt-1">Across all users</p>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Activity" size={24} color="white" />
            </div>
            <span className="text-xs text-success font-medium">Normal</span>
          </div>
          <h3 className="text-sm font-medium text-muted-foreground mb-1">System Health</h3>
          <p className="text-2xl font-bold text-foreground">99.9%</p>
          <p className="text-xs text-muted-foreground mt-1">Uptime</p>
        </div>
      </div>

      {/* Security Alerts */}
      <div className="bg-card border border-border rounded-lg">
        <div className="p-6 border-b border-border">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div>
              <h2 className="text-lg font-semibold text-foreground">Security Alerts</h2>
              <p className="text-sm text-muted-foreground">
                Monitor and respond to security events
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <Select
                options={timeOptions}
                value={timeFilter}
                onChange={setTimeFilter}
                placeholder="Time range"
              />
              <Select
                options={alertOptions}
                value={alertFilter}
                onChange={setAlertFilter}
                placeholder="Alert type"
              />
              <Button variant="outline" iconName="RefreshCw">
                Refresh
              </Button>
            </div>
          </div>
        </div>

        <div className="divide-y divide-border">
          {securityAlerts.map((alert) => {
            const alertIcon = getAlertIcon(alert.type);
            return (
              <div key={alert.id} className="p-6 hover:bg-muted/30 transition-colors duration-200">
                <div className="flex items-start space-x-4">
                  <div className={`mt-1 ${alertIcon.color}`}>
                    <Icon name={alertIcon.name} size={20} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-medium text-foreground">{alert.title}</h3>
                      {getAlertBadge(alert.type)}
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-3">{alert.description}</p>
                    
                    <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center space-x-1">
                        <Icon name="Clock" size={12} />
                        <span>{alert.timestamp}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Icon name="Globe" size={12} />
                        <span>{alert.ip}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Icon name="User" size={12} />
                        <span>{alert.user}</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Icon name="CheckCircle" size={12} />
                        <span>{alert.action}</span>
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="sm" iconName="Eye">
                      View
                    </Button>
                    <Button variant="ghost" size="sm" iconName="MoreHorizontal">
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Login Attempts */}
      <div className="bg-card border border-border rounded-lg">
        <div className="p-6 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Recent Login Attempts</h2>
          <p className="text-sm text-muted-foreground">
            Monitor user authentication activity
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">User</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">IP Address</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Location</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Device</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Status</th>
                <th className="text-left p-4 text-sm font-medium text-muted-foreground">Time</th>
                <th className="text-right p-4 text-sm font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loginAttempts.map((attempt) => (
                <tr key={attempt.id} className="border-t border-border hover:bg-muted/30 transition-colors duration-200">
                  <td className="p-4">
                    <span className="text-sm font-medium text-foreground">{attempt.user}</span>
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-muted-foreground">{attempt.ip}</span>
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-muted-foreground">{attempt.location}</span>
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-muted-foreground">{attempt.device}</span>
                  </td>
                  <td className="p-4">
                    {getStatusBadge(attempt.status)}
                  </td>
                  <td className="p-4">
                    <span className="text-sm text-muted-foreground">{attempt.timestamp}</span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center justify-end space-x-2">
                      <Button variant="ghost" size="sm" iconName="Eye">
                        Details
                      </Button>
                      {attempt.status === 'failed' && (
                        <Button variant="ghost" size="sm" iconName="Ban">
                          Block IP
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SecurityMonitor;