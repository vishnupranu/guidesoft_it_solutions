import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const FeaturedProjects = () => {
  const projects = [
    {
      id: 1,
      title: "E-Commerce Platform Modernization",
      client: "TechCorp Solutions",
      category: "Full-Stack Development",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Complete modernization of legacy e-commerce platform using React, Node.js, and microservices architecture, resulting in 300% performance improvement.",
      technologies: ["React", "Node.js", "MongoDB", "AWS"],
      metrics: [
        { label: "Performance Boost", value: "300%" },
        { label: "Load Time Reduction", value: "2.5s" },
        { label: "User Engagement", value: "+150%" }
      ],
      duration: "6 months",
      teamSize: "8 developers"
    },
    {
      id: 2,
      title: "Cloud Migration & DevOps Implementation",
      client: "Global Finance Inc",
      category: "Cloud & DevOps",
      image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Migrated enterprise applications to AWS cloud with complete CI/CD pipeline implementation, reducing deployment time by 80%.",
      technologies: ["AWS", "Docker", "Kubernetes", "Jenkins"],
      metrics: [
        { label: "Deployment Speed", value: "80% faster" },
        { label: "Cost Reduction", value: "45%" },
        { label: "Uptime Improvement", value: "99.9%" }
      ],
      duration: "4 months",
      teamSize: "6 specialists"
    },
    {
      id: 3,
      title: "Mobile Learning Application",
      client: "EduTech Innovations",
      category: "Mobile Development",
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      description: "Cross-platform mobile learning app with offline capabilities, real-time collaboration, and AI-powered personalized learning paths.",
      technologies: ["React Native", "Firebase", "TensorFlow", "GraphQL"],
      metrics: [
        { label: "User Retention", value: "85%" },
        { label: "App Store Rating", value: "4.8/5" },
        { label: "Daily Active Users", value: "50K+" }
      ],
      duration: "8 months",
      teamSize: "10 developers"
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-accent/10 rounded-full text-accent text-sm font-medium mb-4">
            <Icon name="Briefcase" size={16} className="mr-2" />
            Success Stories
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Featured Projects & Case Studies
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Discover how our expert training translates into real-world success. These projects showcase the capabilities of our graduates and training programs.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="space-y-12">
          {projects.map((project, index) => (
            <div
              key={project.id}
              className={`grid lg:grid-cols-2 gap-8 items-center ${
                index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
              }`}
            >
              {/* Project Image */}
              <div className={`relative ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                <div className="relative overflow-hidden rounded-2xl shadow-2xl">
                  <Image
                    src={project.image}
                    alt={project.title}
                    className="w-full h-80 object-cover hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  
                  {/* Project Category Badge */}
                  <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                    {project.category}
                  </div>
                </div>
              </div>

              {/* Project Content */}
              <div className={`${index % 2 === 1 ? 'lg:col-start-1 lg:row-start-1' : ''}`}>
                <div className="mb-4">
                  <h3 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
                    {project.title}
                  </h3>
                  <p className="text-primary font-medium">{project.client}</p>
                </div>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {project.description}
                </p>
                
                {/* Technologies */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-foreground mb-3">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-full border border-border"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* Metrics */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {project.metrics.map((metric, metricIndex) => (
                    <div key={metricIndex} className="text-center p-4 bg-muted/50 rounded-lg">
                      <div className="text-lg font-bold text-foreground">{metric.value}</div>
                      <div className="text-xs text-muted-foreground">{metric.label}</div>
                    </div>
                  ))}
                </div>
                
                {/* Project Details */}
                <div className="flex items-center space-x-6 text-sm text-muted-foreground mb-6">
                  <div className="flex items-center">
                    <Icon name="Clock" size={16} className="mr-2" />
                    {project.duration}
                  </div>
                  <div className="flex items-center">
                    <Icon name="Users" size={16} className="mr-2" />
                    {project.teamSize}
                  </div>
                </div>
                
                {/* CTA */}
                <button className="inline-flex items-center text-primary hover:text-primary/80 font-medium transition-colors duration-300">
                  View Case Study
                  <Icon name="ArrowRight" size={16} className="ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-card border border-border rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              Ready to Build Your Success Story?
            </h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Join our training programs and develop the skills needed to lead projects like these. Our hands-on approach ensures you're ready for real-world challenges.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-medium hover:bg-primary/90 transition-colors duration-300">
                Start Your Journey
              </button>
              <button className="border border-border text-foreground px-6 py-3 rounded-lg font-medium hover:bg-muted transition-colors duration-300">
                View All Projects
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProjects;