import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const NewsletterSignup = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email) {
      setError('Email is required');
      return;
    }
    
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      setIsSubscribed(true);
      setEmail('');
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const benefits = [
    {
      icon: "BookOpen",
      title: "Weekly Tutorials",
      description: "Get step-by-step guides and coding tutorials delivered to your inbox"
    },
    {
      icon: "TrendingUp",
      title: "Industry Insights",
      description: "Stay ahead with the latest trends and technologies in IT"
    },
    {
      icon: "Users",
      title: "Exclusive Content",
      description: "Access subscriber-only resources and early course announcements"
    },
    {
      icon: "Gift",
      title: "Special Offers",
      description: "Be the first to know about discounts and promotional offers"
    }
  ];

  if (isSubscribed) {
    return (
      <section className="py-20 bg-gradient-to-br from-success/5 to-primary/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-card border border-border rounded-2xl p-12 shadow-lg">
            <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Icon name="CheckCircle" size={32} className="text-success" />
            </div>
            
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Welcome to Our Community!
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8">
              Thank you for subscribing! You'll receive your first newsletter within the next few days. 
              Get ready to accelerate your IT career with exclusive content and insights.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="default" iconName="BookOpen" iconPosition="left">
                Browse Courses
              </Button>
              <Button variant="outline" iconName="MessageCircle" iconPosition="left">
                Join Community
              </Button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-6">
              <Icon name="Mail" size={16} className="mr-2" />
              Stay Connected
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-6">
              Join 25,000+ IT Professionals
            </h2>
            
            <p className="text-lg text-muted-foreground mb-8">
              Get exclusive access to premium content, industry insights, and career-boosting resources. 
              Our newsletter is packed with actionable tips and the latest trends in technology.
            </p>

            {/* Benefits Grid */}
            <div className="grid sm:grid-cols-2 gap-6 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <Icon name={benefit.icon} size={16} className="text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-1">{benefit.title}</h4>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <div className="flex items-center">
                <Icon name="Shield" size={16} className="mr-2 text-success" />
                No spam, ever
              </div>
              <div className="flex items-center">
                <Icon name="Clock" size={16} className="mr-2 text-success" />
                Weekly updates
              </div>
              <div className="flex items-center">
                <Icon name="X" size={16} className="mr-2 text-success" />
                Unsubscribe anytime
              </div>
            </div>
          </div>

          {/* Newsletter Form */}
          <div className="bg-card border border-border rounded-2xl p-8 shadow-lg">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-foreground mb-2">
                Start Your Journey Today
              </h3>
              <p className="text-muted-foreground">
                Join our community and get instant access to exclusive resources
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <Input
                type="email"
                label="Email Address"
                placeholder="Enter your email address"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setError('');
                }}
                error={error}
                required
              />

              <Button
                type="submit"
                variant="default"
                size="lg"
                fullWidth
                loading={isLoading}
                disabled={isLoading}
                iconName="Send"
                iconPosition="right"
              >
                Subscribe Now
              </Button>
            </form>

            {/* Social Proof */}
            <div className="mt-6 pt-6 border-t border-border">
              <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <div className="flex -space-x-2 mr-3">
                    <div className="w-6 h-6 bg-primary rounded-full border-2 border-background"></div>
                    <div className="w-6 h-6 bg-accent rounded-full border-2 border-background"></div>
                    <div className="w-6 h-6 bg-success rounded-full border-2 border-background"></div>
                  </div>
                  <span>25,000+ subscribers</span>
                </div>
                <div className="flex items-center">
                  <Icon name="Star" size={16} className="text-yellow-400 mr-1" />
                  <span>4.9/5 rating</span>
                </div>
              </div>
            </div>

            {/* Free Resources Preview */}
            <div className="mt-6 p-4 bg-muted/50 rounded-lg">
              <h4 className="font-semibold text-foreground mb-2 flex items-center">
                <Icon name="Gift" size={16} className="mr-2 text-primary" />
                Instant Access Bonus
              </h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Complete React Developer Roadmap (PDF)</li>
                <li>• 50+ Coding Interview Questions</li>
                <li>• Exclusive Discord Community Access</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NewsletterSignup;