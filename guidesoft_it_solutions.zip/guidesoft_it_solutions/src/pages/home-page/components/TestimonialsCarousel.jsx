import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const TestimonialsCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "Senior Full-Stack Developer",
      company: "Microsoft",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      companyLogo: "https://images.unsplash.com/photo-1633409361618-c73427e4e206?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      rating: 5,
      content: `The React development course at Guidesoft completely transformed my career. The hands-on projects and expert mentorship helped me land my dream job at Microsoft. The instructors don't just teach theory - they share real-world experience that makes all the difference.`,
      achievement: "Promoted to Senior Developer within 6 months"
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "Cloud Solutions Architect",
      company: "Amazon Web Services",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      companyLogo: "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      rating: 5,
      content: `The AWS certification program exceeded my expectations. The comprehensive curriculum and practical labs prepared me perfectly for both the certification exam and my current role. I went from zero cloud experience to becoming a certified solutions architect in just 4 months.`,
      achievement: "AWS Solutions Architect Professional Certified"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      role: "Data Science Manager",
      company: "Google",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      companyLogo: "https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      rating: 5,
      content: `The Data Science bootcamp was incredibly comprehensive. From Python fundamentals to advanced machine learning, every concept was explained clearly with practical applications. The career support team helped me transition from marketing to data science seamlessly.`,
      achievement: "Career transition from Marketing to Data Science"
    },
    {
      id: 4,
      name: "David Thompson",
      role: "DevOps Engineer",
      company: "Netflix",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      companyLogo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      rating: 5,
      content: `The DevOps program taught me everything from containerization to CI/CD pipelines. The hands-on approach with real projects made complex concepts easy to understand. I'm now leading infrastructure automation at Netflix thanks to the solid foundation I built here.`,
      achievement: "Leading DevOps transformation at Netflix"
    },
    {
      id: 5,
      name: "Lisa Wang",
      role: "Cybersecurity Specialist",
      company: "IBM",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
      companyLogo: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      rating: 5,
      content: `The cybersecurity course provided cutting-edge knowledge in ethical hacking and network security. The practical labs and real-world scenarios prepared me for the challenges I face daily. The certification helped me secure a position at IBM's security division.`,
      achievement: "Certified Ethical Hacker (CEH) and CISSP"
    }
  ];

  useEffect(() => {
    if (isAutoPlaying) {
      const interval = setInterval(() => {
        setCurrentIndex((prevIndex) => 
          prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
        );
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isAutoPlaying, testimonials.length]);

  const goToSlide = (index) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? testimonials.length - 1 : currentIndex - 1);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToNext = () => {
    setCurrentIndex(currentIndex === testimonials.length - 1 ? 0 : currentIndex + 1);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < rating ? "text-yellow-400 fill-current" : "text-gray-300"}
      />
    ));
  };

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-success/10 rounded-full text-success text-sm font-medium mb-4">
            <Icon name="MessageCircle" size={16} className="mr-2" />
            Student Success Stories
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            What Our Graduates Say
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Join thousands of professionals who have transformed their careers through our comprehensive training programs.
          </p>
        </div>

        {/* Testimonials Carousel */}
        <div className="relative">
          <div className="overflow-hidden rounded-2xl">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial) => (
                <div key={testimonial.id} className="w-full flex-shrink-0">
                  <div className="bg-card border border-border rounded-2xl p-8 mx-4">
                    <div className="grid lg:grid-cols-3 gap-8 items-center">
                      {/* Testimonial Content */}
                      <div className="lg:col-span-2">
                        <div className="flex items-center mb-4">
                          {renderStars(testimonial.rating)}
                        </div>
                        
                        <blockquote className="text-lg text-foreground leading-relaxed mb-6">
                          "{testimonial.content}"
                        </blockquote>
                        
                        <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                          <div className="flex items-center text-primary">
                            <Icon name="Trophy" size={16} className="mr-2" />
                            <span className="text-sm font-medium">Achievement</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {testimonial.achievement}
                          </p>
                        </div>
                      </div>
                      
                      {/* Author Info */}
                      <div className="text-center lg:text-left">
                        <div className="relative inline-block mb-4">
                          <Image
                            src={testimonial.avatar}
                            alt={testimonial.name}
                            className="w-24 h-24 rounded-full object-cover mx-auto lg:mx-0"
                          />
                          <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-card border-2 border-background rounded-full flex items-center justify-center">
                            <Image
                              src={testimonial.companyLogo}
                              alt={testimonial.company}
                              className="w-5 h-5 object-contain"
                            />
                          </div>
                        </div>
                        
                        <h4 className="text-xl font-semibold text-foreground mb-1">
                          {testimonial.name}
                        </h4>
                        <p className="text-muted-foreground text-sm mb-1">
                          {testimonial.role}
                        </p>
                        <p className="text-primary text-sm font-medium">
                          {testimonial.company}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={goToPrevious}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-12 h-12 bg-card border border-border rounded-full flex items-center justify-center hover:bg-muted transition-colors duration-300 shadow-lg"
          >
            <Icon name="ChevronLeft" size={20} className="text-foreground" />
          </button>
          
          <button
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-12 h-12 bg-card border border-border rounded-full flex items-center justify-center hover:bg-muted transition-colors duration-300 shadow-lg"
          >
            <Icon name="ChevronRight" size={20} className="text-foreground" />
          </button>
        </div>

        {/* Dots Indicator */}
        <div className="flex justify-center mt-8 space-x-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-3 h-3 rounded-full transition-colors duration-300 ${
                index === currentIndex ? 'bg-primary' : 'bg-border hover:bg-muted-foreground'
              }`}
            />
          ))}
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 pt-16 border-t border-border">
          <div className="text-center">
            <div className="text-3xl font-bold text-foreground mb-2">10,000+</div>
            <div className="text-sm text-muted-foreground">Graduates</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-foreground mb-2">95%</div>
            <div className="text-sm text-muted-foreground">Job Placement Rate</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-foreground mb-2">4.9/5</div>
            <div className="text-sm text-muted-foreground">Average Rating</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-foreground mb-2">500+</div>
            <div className="text-sm text-muted-foreground">Partner Companies</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsCarousel;