import React from 'react';
import Icon from '../../../components/AppIcon';

const ServicesOverview = () => {
  const services = [
    {
      id: 1,
      icon: "Code2",
      title: "Web Development",
      description: "Master modern web technologies including React, Node.js, and full-stack development with hands-on projects and real-world applications.",
      features: ["React & Vue.js", "Node.js & Express", "Database Design", "API Development"]
    },
    {
      id: 2,
      icon: "Cloud",
      title: "Cloud Computing",
      description: "Learn AWS, Azure, and Google Cloud platforms with comprehensive training on deployment, scaling, and cloud architecture.",
      features: ["AWS Certification", "Azure Solutions", "DevOps Practices", "Cloud Security"]
    },
    {
      id: 3,
      icon: "Smartphone",
      title: "Mobile Development",
      description: "Build native and cross-platform mobile applications using React Native, Flutter, and native iOS/Android development.",
      features: ["React Native", "Flutter", "iOS Development", "Android Studio"]
    },
    {
      id: 4,
      icon: "Database",
      title: "Data Science",
      description: "Dive into data analytics, machine learning, and AI with Python, R, and advanced statistical modeling techniques.",
      features: ["Python & R", "Machine Learning", "Data Visualization", "Statistical Analysis"]
    },
    {
      id: 5,
      icon: "Shield",
      title: "Cybersecurity",
      description: "Comprehensive security training covering ethical hacking, network security, and compliance frameworks.",
      features: ["Ethical Hacking", "Network Security", "Compliance", "Risk Assessment"]
    },
    {
      id: 6,
      icon: "Zap",
      title: "DevOps & Automation",
      description: "Learn CI/CD pipelines, containerization, and infrastructure automation with Docker, Kubernetes, and Jenkins.",
      features: ["Docker & Kubernetes", "CI/CD Pipelines", "Infrastructure as Code", "Monitoring"]
    }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
            <Icon name="Star" size={16} className="mr-2" />
            Our Expertise
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
            Comprehensive IT Training Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            From beginner-friendly courses to advanced certifications, we offer a complete range of IT training programs designed to accelerate your career growth.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="group bg-card border border-border rounded-xl p-6 hover:shadow-lg hover:border-primary/20 transition-all duration-300"
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-300">
                  <Icon name={service.icon} size={24} className="text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground ml-4">
                  {service.title}
                </h3>
              </div>
              
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {service.description}
              </p>
              
              <div className="space-y-2">
                {service.features.map((feature, index) => (
                  <div key={index} className="flex items-center text-sm">
                    <Icon name="Check" size={16} className="text-success mr-2 flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 pt-4 border-t border-border">
                <button className="text-primary hover:text-primary/80 text-sm font-medium flex items-center group-hover:translate-x-1 transition-transform duration-300">
                  Learn More
                  <Icon name="ArrowRight" size={16} className="ml-2" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Start Your IT Journey?</h3>
            <p className="text-primary-foreground/90 mb-6 max-w-2xl mx-auto">
              Join thousands of professionals who have transformed their careers with our expert-led training programs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-primary px-6 py-3 rounded-lg font-medium hover:bg-white/90 transition-colors duration-300">
                View All Courses
              </button>
              <button className="border border-white/20 text-white px-6 py-3 rounded-lg font-medium hover:bg-white/10 transition-colors duration-300">
                Schedule Consultation
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesOverview;