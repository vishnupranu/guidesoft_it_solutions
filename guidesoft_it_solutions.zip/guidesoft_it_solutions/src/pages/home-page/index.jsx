import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import PublicHeader from '../../components/ui/PublicHeader';
import HeroSection from './components/HeroSection';
import ServicesOverview from './components/ServicesOverview';
import FeaturedProjects from './components/FeaturedProjects';
import TestimonialsCarousel from './components/TestimonialsCarousel';
import LatestBlogPosts from './components/LatestBlogPosts';
import NewsletterSignup from './components/NewsletterSignup';
import Footer from './components/Footer';

const HomePage = () => {
  useEffect(() => {
    // Smooth scrolling for anchor links
    const handleSmoothScroll = (e) => {
      const href = e.target.getAttribute('href');
      if (href && href.startsWith('#')) {
        e.preventDefault();
        const element = document.querySelector(href);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }
    };

    document.addEventListener('click', handleSmoothScroll);
    return () => document.removeEventListener('click', handleSmoothScroll);
  }, []);

  return (
    <>
      <Helmet>
        <title>Guidesoft IT Solutions - Transform Your IT Career with Expert Training</title>
        <meta 
          name="description" 
          content="Master cutting-edge technologies with industry-leading instructors. Comprehensive IT training programs in web development, cloud computing, data science, and more. Join 10,000+ successful graduates." 
        />
        <meta name="keywords" content="IT training, web development, cloud computing, data science, cybersecurity, programming courses, tech education" />
        <meta property="og:title" content="Guidesoft IT Solutions - Transform Your IT Career" />
        <meta property="og:description" content="Comprehensive IT training programs designed for real-world success. Expert instructors, hands-on projects, and career support." />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <link rel="canonical" href="/home-page" />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <PublicHeader />

        {/* Main Content */}
        <main>
          {/* Hero Section */}
          <HeroSection />

          {/* Services Overview */}
          <ServicesOverview />

          {/* Featured Projects */}
          <FeaturedProjects />

          {/* Testimonials */}
          <TestimonialsCarousel />

          {/* Latest Blog Posts */}
          <LatestBlogPosts />

          {/* Newsletter Signup */}
          <NewsletterSignup />
        </main>

        {/* Footer */}
        <Footer />
      </div>
    </>
  );
};

export default HomePage;