import React, { useState, useEffect } from 'react';
import AuthenticatedHeader from '../../components/ui/AuthenticatedHeader';
import RoleBasedSidebar from '../../components/ui/RoleBasedSidebar';
import MetricsCard from './components/MetricsCard';
import CourseTable from './components/CourseTable';
import StudentOverview from './components/StudentOverview';
import ContentCreationPanel from './components/ContentCreationPanel';
import ActivityFeed from './components/ActivityFeed';
import SearchAndFilter from './components/SearchAndFilter';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';

const TrainerDashboard = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedView, setSelectedView] = useState('overview');

  // Mock user data
  const user = {
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@guidesoft.com",
    avatar: null,
    role: "trainer"
  };

  // Mock metrics data
  const metricsData = [
    {
      title: "Total Students",
      value: "1,247",
      change: "+12.5%",
      changeType: "positive",
      icon: "Users",
      color: "primary"
    },
    {
      title: "Active Courses",
      value: "12",
      change: "+2",
      changeType: "positive",
      icon: "BookOpen",
      color: "success"
    },
    {
      title: "Completion Rate",
      value: "87.3%",
      change: "+5.2%",
      changeType: "positive",
      icon: "TrendingUp",
      color: "warning"
    },
    {
      title: "Avg. Rating",
      value: "4.8",
      change: "+0.2",
      changeType: "positive",
      icon: "Star",
      color: "error"
    }
  ];

  // Mock courses data
  const coursesData = [
    {
      id: 1,
      name: "Advanced React Development",
      category: "Web Development",
      enrolledStudents: 156,
      averageProgress: 73,
      status: "active",
      icon: "Code",
      color: "bg-blue-500"
    },
    {
      id: 2,
      name: "Node.js Backend Mastery",
      category: "Backend Development",
      enrolledStudents: 89,
      averageProgress: 65,
      status: "active",
      icon: "Server",
      color: "bg-green-500"
    },
    {
      id: 3,
      name: "Database Design Fundamentals",
      category: "Database",
      enrolledStudents: 234,
      averageProgress: 82,
      status: "active",
      icon: "Database",
      color: "bg-purple-500"
    },
    {
      id: 4,
      name: "DevOps with Docker",
      category: "DevOps",
      enrolledStudents: 67,
      averageProgress: 45,
      status: "draft",
      icon: "Container",
      color: "bg-orange-500"
    },
    {
      id: 5,
      name: "Cloud Computing Essentials",
      category: "Cloud",
      enrolledStudents: 198,
      averageProgress: 91,
      status: "active",
      icon: "Cloud",
      color: "bg-cyan-500"
    }
  ];

  // Mock recent enrollments
  const recentEnrollments = [
    {
      id: 1,
      studentName: "Alex Thompson",
      courseName: "Advanced React Development",
      enrolledAt: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
    },
    {
      id: 2,
      studentName: "Maria Garcia",
      courseName: "Node.js Backend Mastery",
      enrolledAt: new Date(Date.now() - 5 * 60 * 60 * 1000) // 5 hours ago
    },
    {
      id: 3,
      studentName: "David Chen",
      courseName: "Database Design Fundamentals",
      enrolledAt: new Date(Date.now() - 8 * 60 * 60 * 1000) // 8 hours ago
    },
    {
      id: 4,
      studentName: "Emily Rodriguez",
      courseName: "Cloud Computing Essentials",
      enrolledAt: new Date(Date.now() - 12 * 60 * 60 * 1000) // 12 hours ago
    }
  ];

  // Mock pending submissions
  const pendingSubmissions = [
    {
      id: 1,
      assignmentTitle: "React Hooks Implementation",
      studentName: "John Smith",
      courseName: "Advanced React Development",
      submittedAt: new Date(Date.now() - 3 * 60 * 60 * 1000) // 3 hours ago
    },
    {
      id: 2,
      assignmentTitle: "API Design Project",
      studentName: "Lisa Wang",
      courseName: "Node.js Backend Mastery",
      submittedAt: new Date(Date.now() - 6 * 60 * 60 * 1000) // 6 hours ago
    },
    {
      id: 3,
      assignmentTitle: "Database Schema Design",
      studentName: "Michael Brown",
      courseName: "Database Design Fundamentals",
      submittedAt: new Date(Date.now() - 10 * 60 * 60 * 1000) // 10 hours ago
    }
  ];

  // Mock students needing attention
  const studentsNeedingAttention = [
    {
      id: 1,
      name: "Jennifer Wilson",
      reason: "No activity for 7 days",
      lastActive: "7 days ago"
    },
    {
      id: 2,
      name: "Robert Taylor",
      reason: "Failing multiple assignments",
      lastActive: "2 days ago"
    },
    {
      id: 3,
      name: "Amanda Davis",
      reason: "Requested help multiple times",
      lastActive: "1 day ago"
    }
  ];

  // Mock activity feed
  const activitiesData = [
    {
      id: 1,
      type: "enrollments",
      studentName: "Alex Thompson",
      action: "enrolled in",
      target: "Advanced React Development",
      course: "React Course",
      timestamp: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      actionRequired: false
    },
    {
      id: 2,
      type: "completions",
      studentName: "Maria Garcia",
      action: "completed",
      target: "Module 3: State Management",
      course: "React Course",
      timestamp: new Date(Date.now() - 45 * 60 * 1000), // 45 minutes ago
      actionRequired: false
    },
    {
      id: 3,
      type: "submissions",
      studentName: "David Chen",
      action: "submitted",
      target: "Final Project",
      course: "Database Course",
      details: "Awaiting review",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      actionRequired: true
    },
    {
      id: 4,
      type: "messages",
      studentName: "Emily Rodriguez",
      action: "sent a message about",
      target: "Assignment clarification",
      course: "Cloud Course",
      timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000), // 3 hours ago
      actionRequired: true
    },
    {
      id: 5,
      type: "enrollments",
      studentName: "James Wilson",
      action: "enrolled in",
      target: "Node.js Backend Mastery",
      course: "Backend Course",
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      actionRequired: false
    }
  ];

  // Event handlers
  const handleEditCourse = (courseId) => {
    console.log('Edit course:', courseId);
  };

  const handleViewAnalytics = (courseId) => {
    console.log('View analytics for course:', courseId);
  };

  const handleMessageStudents = (courseId) => {
    console.log('Message students in course:', courseId);
  };

  const handleCreateCourse = () => {
    console.log('Create new course');
  };

  const handleUploadMaterial = () => {
    console.log('Upload material');
  };

  const handleScheduleSession = () => {
    console.log('Schedule session');
  };

  const handleSearch = (searchTerm) => {
    console.log('Search:', searchTerm);
  };

  const handleFilter = (filters) => {
    console.log('Filter:', filters);
  };

  const handleExport = () => {
    console.log('Export data');
  };

  const viewOptions = [
    { value: 'overview', label: 'Overview', icon: 'LayoutDashboard' },
    { value: 'courses', label: 'Courses', icon: 'BookOpen' },
    { value: 'students', label: 'Students', icon: 'Users' },
    { value: 'content', label: 'Content', icon: 'Library' },
    { value: 'analytics', label: 'Analytics', icon: 'BarChart3' }
  ];

  return (
    <div className="min-h-screen bg-background">
      <AuthenticatedHeader user={user} />
      
      <div className="flex">
        <RoleBasedSidebar 
          user={user}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />
        
        <main className={`flex-1 transition-all duration-300 ${
          isSidebarCollapsed ? 'ml-16' : 'ml-64'
        } mt-16 p-6`}>
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Trainer Dashboard</h1>
                <p className="text-muted-foreground mt-1">
                  Manage your courses, students, and content creation
                </p>
              </div>
              <div className="flex items-center space-x-3 mt-4 sm:mt-0">
                <Button variant="outline" iconName="Calendar">
                  Schedule
                </Button>
                <Button variant="default" iconName="Plus">
                  Create Course
                </Button>
              </div>
            </div>
          </div>

          {/* View Toggle */}
          <div className="flex flex-wrap gap-2 mb-6">
            {viewOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => setSelectedView(option.value)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedView === option.value
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80'
                }`}
              >
                <Icon name={option.icon} size={16} />
                <span>{option.label}</span>
              </button>
            ))}
          </div>

          {/* Search and Filter */}
          <SearchAndFilter
            onSearch={handleSearch}
            onFilter={handleFilter}
            onExport={handleExport}
          />

          {/* Overview View */}
          {selectedView === 'overview' && (
            <div className="space-y-8">
              {/* Metrics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {metricsData.map((metric, index) => (
                  <MetricsCard key={index} {...metric} />
                ))}
              </div>

              {/* Main Content Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column - Course Management */}
                <div className="lg:col-span-2 space-y-8">
                  <CourseTable
                    courses={coursesData}
                    onEditCourse={handleEditCourse}
                    onViewAnalytics={handleViewAnalytics}
                    onMessageStudents={handleMessageStudents}
                  />
                </div>

                {/* Right Column - Student Overview & Content Creation */}
                <div className="space-y-8">
                  <StudentOverview
                    recentEnrollments={recentEnrollments}
                    pendingSubmissions={pendingSubmissions}
                    studentsNeedingAttention={studentsNeedingAttention}
                  />
                </div>
              </div>

              {/* Bottom Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <ContentCreationPanel
                  onCreateCourse={handleCreateCourse}
                  onUploadMaterial={handleUploadMaterial}
                  onScheduleSession={handleScheduleSession}
                />
                <ActivityFeed activities={activitiesData} />
              </div>
            </div>
          )}

          {/* Other Views */}
          {selectedView === 'courses' && (
            <div className="space-y-6">
              <CourseTable
                courses={coursesData}
                onEditCourse={handleEditCourse}
                onViewAnalytics={handleViewAnalytics}
                onMessageStudents={handleMessageStudents}
              />
            </div>
          )}

          {selectedView === 'students' && (
            <div className="space-y-6">
              <StudentOverview
                recentEnrollments={recentEnrollments}
                pendingSubmissions={pendingSubmissions}
                studentsNeedingAttention={studentsNeedingAttention}
              />
            </div>
          )}

          {selectedView === 'content' && (
            <div className="space-y-6">
              <ContentCreationPanel
                onCreateCourse={handleCreateCourse}
                onUploadMaterial={handleUploadMaterial}
                onScheduleSession={handleScheduleSession}
              />
            </div>
          )}

          {selectedView === 'analytics' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {metricsData.map((metric, index) => (
                  <MetricsCard key={index} {...metric} />
                ))}
              </div>
              <ActivityFeed activities={activitiesData} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default TrainerDashboard;