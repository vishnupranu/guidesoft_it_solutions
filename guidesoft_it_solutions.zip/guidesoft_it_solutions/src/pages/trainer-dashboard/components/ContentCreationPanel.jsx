import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ContentCreationPanel = ({ onCreateCourse, onUploadMaterial, onScheduleSession }) => {
  const quickActions = [
    {
      id: 'create-course',
      title: 'Create New Course',
      description: 'Build a comprehensive training program',
      icon: 'Plus',
      color: 'bg-primary',
      action: onCreateCourse
    },
    {
      id: 'upload-material',
      title: 'Upload Materials',
      description: 'Add resources, videos, and documents',
      icon: 'Upload',
      color: 'bg-success',
      action: onUploadMaterial
    },
    {
      id: 'schedule-session',
      title: 'Schedule Live Session',
      description: 'Plan interactive training sessions',
      icon: 'Calendar',
      color: 'bg-warning',
      action: onScheduleSession
    }
  ];

  const recentTemplates = [
    {
      id: 1,
      name: 'JavaScript Fundamentals',
      type: 'Course Template',
      lastUsed: '2 days ago',
      icon: 'Code'
    },
    {
      id: 2,
      name: 'React Components',
      type: 'Lesson Template',
      lastUsed: '1 week ago',
      icon: 'Component'
    },
    {
      id: 3,
      name: 'Database Design',
      type: 'Assignment Template',
      lastUsed: '2 weeks ago',
      icon: 'Database'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {quickActions.map((action) => (
            <button
              key={action.id}
              onClick={action.action}
              className="p-4 border border-border rounded-lg hover:bg-muted/30 transition-colors text-left group"
            >
              <div className="flex items-center space-x-3 mb-3">
                <div className={`w-10 h-10 ${action.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <Icon name={action.icon} size={20} color="white" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {action.title}
                  </h4>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{action.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Templates */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Recent Templates</h3>
          <Button variant="ghost" size="sm" iconName="ArrowRight">
            View All
          </Button>
        </div>
        <div className="space-y-3">
          {recentTemplates.map((template) => (
            <div key={template.id} className="flex items-center space-x-3 p-3 border border-border rounded-lg hover:bg-muted/30 transition-colors cursor-pointer">
              <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                <Icon name={template.icon} size={16} className="text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{template.name}</p>
                <p className="text-sm text-muted-foreground truncate">{template.type}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">{template.lastUsed}</p>
                <Button variant="ghost" size="xs" iconName="Copy" className="mt-1">
                  Use
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Content Statistics */}
      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Content Statistics</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Icon name="BookOpen" size={20} className="text-primary" />
            </div>
            <p className="text-2xl font-bold text-foreground">12</p>
            <p className="text-sm text-muted-foreground">Active Courses</p>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Icon name="FileText" size={20} className="text-success" />
            </div>
            <p className="text-2xl font-bold text-foreground">48</p>
            <p className="text-sm text-muted-foreground">Total Lessons</p>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Icon name="Video" size={20} className="text-warning" />
            </div>
            <p className="text-2xl font-bold text-foreground">156</p>
            <p className="text-sm text-muted-foreground">Video Hours</p>
          </div>
          <div className="text-center p-4 bg-muted/30 rounded-lg">
            <div className="w-12 h-12 bg-error/10 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Icon name="Download" size={20} className="text-error" />
            </div>
            <p className="text-2xl font-bold text-foreground">324</p>
            <p className="text-sm text-muted-foreground">Resources</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentCreationPanel;