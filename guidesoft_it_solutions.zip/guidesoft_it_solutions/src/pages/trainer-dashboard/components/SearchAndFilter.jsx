import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const SearchAndFilter = ({ onSearch, onFilter, onExport }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [dateRange, setDateRange] = useState('');

  const categoryOptions = [
    { value: '', label: 'All Categories' },
    { value: 'web-development', label: 'Web Development' },
    { value: 'mobile-development', label: 'Mobile Development' },
    { value: 'data-science', label: 'Data Science' },
    { value: 'devops', label: 'DevOps' },
    { value: 'cybersecurity', label: 'Cybersecurity' },
    { value: 'cloud-computing', label: 'Cloud Computing' }
  ];

  const statusOptions = [
    { value: '', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'draft', label: 'Draft' },
    { value: 'completed', label: 'Completed' },
    { value: 'archived', label: 'Archived' }
  ];

  const dateRangeOptions = [
    { value: '', label: 'All Time' },
    { value: 'today', label: 'Today' },
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: 'quarter', label: 'This Quarter' },
    { value: 'year', label: 'This Year' }
  ];

  const handleSearch = (value) => {
    setSearchTerm(value);
    onSearch(value);
  };

  const handleCategoryChange = (value) => {
    setSelectedCategory(value);
    onFilter({ category: value, status: selectedStatus, dateRange });
  };

  const handleStatusChange = (value) => {
    setSelectedStatus(value);
    onFilter({ category: selectedCategory, status: value, dateRange });
  };

  const handleDateRangeChange = (value) => {
    setDateRange(value);
    onFilter({ category: selectedCategory, status: selectedStatus, dateRange: value });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('');
    setSelectedStatus('');
    setDateRange('');
    onSearch('');
    onFilter({ category: '', status: '', dateRange: '' });
  };

  const hasActiveFilters = searchTerm || selectedCategory || selectedStatus || dateRange;

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Search */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Icon 
              name="Search" 
              size={18} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
            />
            <input
              type="text"
              placeholder="Search courses, students, or content..."
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all duration-200"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <Select
            options={categoryOptions}
            value={selectedCategory}
            onChange={handleCategoryChange}
            placeholder="Category"
            className="min-w-[140px]"
          />
          
          <Select
            options={statusOptions}
            value={selectedStatus}
            onChange={handleStatusChange}
            placeholder="Status"
            className="min-w-[120px]"
          />
          
          <Select
            options={dateRangeOptions}
            value={dateRange}
            onChange={handleDateRangeChange}
            placeholder="Date Range"
            className="min-w-[140px]"
          />

          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              iconName="X"
              onClick={clearFilters}
            >
              Clear
            </Button>
          )}

          <div className="flex items-center space-x-2 border-l border-border pl-3">
            <Button
              variant="outline"
              size="sm"
              iconName="Download"
              onClick={onExport}
            >
              Export
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              iconName="Filter"
            >
              More Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-border">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          
          {searchTerm && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
              Search: "{searchTerm}"
              <button
                onClick={() => handleSearch('')}
                className="ml-1.5 hover:text-primary/80"
              >
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          
          {selectedCategory && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success/10 text-success">
              Category: {categoryOptions.find(opt => opt.value === selectedCategory)?.label}
              <button
                onClick={() => handleCategoryChange('')}
                className="ml-1.5 hover:text-success/80"
              >
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          
          {selectedStatus && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-warning/10 text-warning">
              Status: {statusOptions.find(opt => opt.value === selectedStatus)?.label}
              <button
                onClick={() => handleStatusChange('')}
                className="ml-1.5 hover:text-warning/80"
              >
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          
          {dateRange && (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent/10 text-accent">
              Date: {dateRangeOptions.find(opt => opt.value === dateRange)?.label}
              <button
                onClick={() => handleDateRangeChange('')}
                className="ml-1.5 hover:text-accent/80"
              >
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchAndFilter;