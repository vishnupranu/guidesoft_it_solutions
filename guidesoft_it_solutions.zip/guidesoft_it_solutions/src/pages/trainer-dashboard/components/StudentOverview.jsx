import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const StudentOverview = ({ recentEnrollments, pendingSubmissions, studentsNeedingAttention }) => {
  const formatDate = (date) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Recent Enrollments */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Recent Enrollments</h3>
          <Button variant="ghost" size="sm" iconName="ArrowRight">
            View All
          </Button>
        </div>
        <div className="space-y-3">
          {recentEnrollments.map((enrollment) => (
            <div key={enrollment.id} className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Icon name="User" size={16} color="white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{enrollment.studentName}</p>
                <p className="text-sm text-muted-foreground truncate">{enrollment.courseName}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">{formatDate(enrollment.enrolledAt)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pending Submissions */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Pending Reviews</h3>
          <span className="bg-warning/10 text-warning px-2 py-1 rounded-full text-xs font-medium">
            {pendingSubmissions.length} pending
          </span>
        </div>
        <div className="space-y-3">
          {pendingSubmissions.map((submission) => (
            <div key={submission.id} className="flex items-center space-x-3 p-3 border border-border rounded-lg hover:bg-muted/30 transition-colors">
              <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
                <Icon name="FileText" size={16} className="text-warning" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{submission.assignmentTitle}</p>
                <p className="text-sm text-muted-foreground truncate">
                  by {submission.studentName} • {submission.courseName}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted-foreground">{formatDate(submission.submittedAt)}</p>
                <Button variant="ghost" size="xs" iconName="Eye" className="mt-1">
                  Review
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Students Needing Attention */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Students Needing Attention</h3>
          <span className="bg-error/10 text-error px-2 py-1 rounded-full text-xs font-medium">
            {studentsNeedingAttention.length} students
          </span>
        </div>
        <div className="space-y-3">
          {studentsNeedingAttention.map((student) => (
            <div key={student.id} className="flex items-center space-x-3 p-3 border border-border rounded-lg hover:bg-muted/30 transition-colors">
              <div className="w-10 h-10 bg-error/10 rounded-lg flex items-center justify-center">
                <Icon name="AlertTriangle" size={16} className="text-error" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{student.name}</p>
                <p className="text-sm text-muted-foreground truncate">{student.reason}</p>
              </div>
              <div className="text-right">
                <div className="flex items-center space-x-1 mb-1">
                  <Icon name="Clock" size={12} className="text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{student.lastActive}</span>
                </div>
                <Button variant="ghost" size="xs" iconName="MessageSquare">
                  Contact
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StudentOverview;