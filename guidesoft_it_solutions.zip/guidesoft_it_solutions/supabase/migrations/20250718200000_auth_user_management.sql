-- Location: supabase/migrations/20250718200000_auth_user_management.sql
-- Auth & User Management Module - Complete Authentication System

-- Step 1: Create custom types
CREATE TYPE public.user_role AS ENUM ('admin', 'trainer', 'student');
CREATE TYPE public.experience_level AS ENUM ('beginner', 'intermediate', 'advanced', 'expert');

-- Step 2: Create user profiles table (intermediary for auth relationships)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    full_name TEXT GENERATED ALWAYS AS (first_name || ' ' || last_name) STORED,
    role public.user_role DEFAULT 'student'::public.user_role,
    experience_level public.experience_level,
    interests TEXT[] DEFAULT '{}',
    expertise TEXT[] DEFAULT '{}',
    certifications TEXT[] DEFAULT '{}',
    avatar_url TEXT,
    bio TEXT,
    is_active BOOLEAN DEFAULT true,
    marketing_emails BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 3: Create courses table (for trainer/student relationship)
CREATE TABLE public.courses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    trainer_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    is_published BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Step 4: Create enrollments table (student-course relationship)
CREATE TABLE public.enrollments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    student_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
    enrolled_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    is_completed BOOLEAN DEFAULT false,
    UNIQUE(student_id, course_id)
);

-- Step 5: Create indexes for performance
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX idx_courses_trainer_id ON public.courses(trainer_id);
CREATE INDEX idx_courses_published ON public.courses(is_published);
CREATE INDEX idx_enrollments_student_id ON public.enrollments(student_id);
CREATE INDEX idx_enrollments_course_id ON public.enrollments(course_id);

-- Step 6: Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;

-- Step 7: Create helper functions for RLS
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = auth.uid() AND up.role = 'admin'::public.user_role
)
$$;

CREATE OR REPLACE FUNCTION public.is_trainer()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.user_profiles up
    WHERE up.id = auth.uid() AND up.role = 'trainer'::public.user_role
)
$$;

CREATE OR REPLACE FUNCTION public.is_course_owner(course_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.courses c
    WHERE c.id = course_uuid AND c.trainer_id = auth.uid()
)
$$;

CREATE OR REPLACE FUNCTION public.is_enrolled_student(course_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.enrollments e
    WHERE e.course_id = course_uuid AND e.student_id = auth.uid()
)
$$;

-- Step 8: Create RLS policies
-- User profiles - users can view their own profile, admins can view all
CREATE POLICY "users_view_own_profile" ON public.user_profiles
FOR SELECT TO authenticated
USING (auth.uid() = id OR public.is_admin());

CREATE POLICY "users_update_own_profile" ON public.user_profiles
FOR UPDATE TO authenticated
USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Courses - public read for published courses, trainers manage their own
CREATE POLICY "public_view_published_courses" ON public.courses
FOR SELECT TO public
USING (is_published = true);

CREATE POLICY "trainers_manage_own_courses" ON public.courses
FOR ALL TO authenticated
USING (trainer_id = auth.uid() OR public.is_admin())
WITH CHECK (trainer_id = auth.uid() OR public.is_admin());

-- Enrollments - students manage their own enrollments
CREATE POLICY "students_manage_own_enrollments" ON public.enrollments
FOR ALL TO authenticated
USING (student_id = auth.uid() OR public.is_course_owner(course_id) OR public.is_admin())
WITH CHECK (student_id = auth.uid() OR public.is_admin());

-- Step 9: Create trigger function for profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO public.user_profiles (
        id, 
        email, 
        first_name, 
        last_name, 
        role,
        experience_level,
        interests,
        expertise,
        certifications,
        marketing_emails
    )
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'first_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'last_name', ''),
        COALESCE((NEW.raw_user_meta_data->>'role')::public.user_role, 'student'::public.user_role),
        COALESCE((NEW.raw_user_meta_data->>'experience_level')::public.experience_level, NULL),
        COALESCE(array(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'interests')), '{}'),
        COALESCE(array(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'expertise')), '{}'),
        COALESCE(array(SELECT jsonb_array_elements_text(NEW.raw_user_meta_data->'certifications')), '{}'),
        COALESCE((NEW.raw_user_meta_data->>'marketing_emails')::boolean, false)
    );
    RETURN NEW;
END;
$$;

-- Step 10: Create trigger for new user creation
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Step 11: Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Step 12: Create updated_at triggers
CREATE TRIGGER update_user_profiles_updated_at
    BEFORE UPDATE ON public.user_profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_courses_updated_at
    BEFORE UPDATE ON public.courses
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Step 13: Create sample data
DO $$
DECLARE
    admin_uuid UUID := gen_random_uuid();
    trainer_uuid UUID := gen_random_uuid();
    student_uuid UUID := gen_random_uuid();
    course1_uuid UUID := gen_random_uuid();
    course2_uuid UUID := gen_random_uuid();
BEGIN
    -- Create auth users with required fields
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (admin_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@guidesoft.com', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"first_name": "Admin", "last_name": "User", "role": "admin", "experience_level": "expert"}'::jsonb,
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (trainer_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'trainer@guidesoft.com', crypt('trainer123', gen_salt('bf', 10)), now(), now(), now(),
         '{"first_name": "Trainer", "last_name": "Smith", "role": "trainer", "experience_level": "advanced", "expertise": ["JavaScript", "React", "Node.js"]}'::jsonb,
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (student_uuid, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'student@guidesoft.com', crypt('student123', gen_salt('bf', 10)), now(), now(), now(),
         '{"first_name": "Student", "last_name": "Johnson", "role": "student", "experience_level": "beginner", "interests": ["Web Development", "Mobile Apps"]}'::jsonb,
         '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Create sample courses
    INSERT INTO public.courses (id, title, description, trainer_id, is_published) VALUES
        (course1_uuid, 'React Fundamentals', 'Learn the basics of React development', trainer_uuid, true),
        (course2_uuid, 'Advanced JavaScript', 'Master advanced JavaScript concepts', trainer_uuid, true);

    -- Create sample enrollment
    INSERT INTO public.enrollments (student_id, course_id, progress) VALUES
        (student_uuid, course1_uuid, 25),
        (student_uuid, course2_uuid, 0);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key error during sample data creation: %', SQLERRM;
    WHEN unique_violation THEN
        RAISE NOTICE 'Unique constraint error during sample data creation: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Unexpected error during sample data creation: %', SQLERRM;
END $$;

-- Step 14: Create cleanup function for development
CREATE OR REPLACE FUNCTION public.cleanup_test_data()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    auth_user_ids_to_delete UUID[];
BEGIN
    -- Get auth user IDs to delete
    SELECT ARRAY_AGG(id) INTO auth_user_ids_to_delete
    FROM auth.users
    WHERE email LIKE '%@guidesoft.com';

    -- Delete in dependency order
    DELETE FROM public.enrollments WHERE student_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.courses WHERE trainer_id = ANY(auth_user_ids_to_delete);
    DELETE FROM public.user_profiles WHERE id = ANY(auth_user_ids_to_delete);
    DELETE FROM auth.users WHERE id = ANY(auth_user_ids_to_delete);

EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE NOTICE 'Foreign key constraint prevents deletion: %', SQLERRM;
    WHEN OTHERS THEN
        RAISE NOTICE 'Cleanup failed: %', SQLERRM;
END;
$$;